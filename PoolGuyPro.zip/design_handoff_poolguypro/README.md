# Handoff: PoolGuyPro — iOS App Design

## Overview

PoolGuyPro is a marketplace app for pool service professionals ("pool guys") in South Florida. It connects pool techs to:

1. **Quick Pools** — single-pool job postings (the heart of the app). Other techs in the area can apply and quickly take on work nearby.
2. **Marketplace** — buy/rent pool equipment (pumps, filters, vacuums, heaters, tools) and buy/sell entire residential pool service **routes**.
3. **Work** — full-time hiring board, freelance technician directory, and **vacation coverage** matching (a pool guy going on vacation posts which days/regions they need covered).
4. **Profile** — user profile, ratings, subscription tier management.
5. **Home** — aggregated dashboard with the user's own listings, featured opportunities, and today's pool jobs.

The app uses a **freemium subscription model**:

- **Free** — Browse Marketplace, post listings (limited), see Quick Pools but cannot interact.
- **Premium** ($9.99/mo) — Full access to Quick Pools: apply, contact posters, see access details. **Today's Pool Jobs on Home is Premium-only.**
- **Pro** ($19.99/mo) — Everything in Premium plus profile boost, unlimited applications, priority placement.

App is **trilingual**: English, Portuguese (Brazil), Spanish — switchable from any screen via a globe pill.

## About the Design Files

The files in this bundle are **design references created in HTML/React** — high-fidelity prototypes that demonstrate the intended look, layout, and behavior. **They are not production code to copy directly.**

The task is to **recreate these designs in your real iOS app codebase** (SwiftUI / UIKit / React Native — whichever your project uses) using your established patterns, navigation system, networking layer, and component library. If your project does not yet have a codebase, use the design files to inform the choice of stack (SwiftUI is the natural fit for an iOS-first app of this kind) and implement there.

## Fidelity

**High-fidelity.** The mocks include final colors, typography, spacing, iconography, copy (in all three languages), and interaction behaviors. Recreate the UI pixel-perfectly using your codebase's existing patterns. Where exact spacing or sizes are not noted in this README, **read the JSX source files** — every measurement in the HTML is intentional.

## Screens / Views

### 1. Home (`screens/home.jsx`)

**Purpose:** Dashboard. User's listings, featured opportunities, Today's Pool Jobs (Premium-gated).

**Layout (top to bottom):**

- **Navy header** (gradient `--pg-navy-900` → `--pg-blue-600`):
  - Wordmark "PoolGuy**PRO**" with water-drop pill mark, subtitle ("Buy, sell and rent pool equipment")
  - Top-right: language pill + bell icon (with red unread badge)
- **"My Listings" hero card** (overlapping header by `-58px`):
  - White card with title + listing count chip
  - 2-column grid of 2 sample listings (Rental + Route)
- **Premium upsell banner** — cyan→teal gradient with crown icon
- **Featured Listings** — horizontal scroll of cards (215px wide, 102px tall image)
- **Today's Pool Jobs** section:
  - **Premium-only.** Free + Pro users see jobs but with locked icon and "Premium" chip instead of price.
  - Free/Pro: Upsell strip "Subscribe to Premium to apply & contact" appears above list.
  - Tapping any card: Premium → goes to Quick Pools tab; Free/Pro → opens paywall sheet.

### 2. Marketplace (`screens/marketplace.jsx`)

**Purpose:** Browse equipment for sale/rent and pool routes for sale.

**Layout:**

- Navy header with back button + plus button (opens post menu)
- **Filter card** (overlapping header):
  - 3 large pill buttons in a row: **Buy** (cart icon), **Rent** (key icon), **Routes** (pin icon). Each shows label + subtitle ("Equipment for sale" / "Equipment to rent" / "Routes for sale"). Selected = solid blue with white-on-blue icon.
  - Search input (only for Buy/Rent)
  - Horizontal scrollable category chips: All, Pumps, Filters, Vacuum, Heaters, Tools
- **Equipment list** (Buy/Rent) — 2-column grid of cards (image + name + condition chip + description + price + seller)
- **Routes list** (Routes) — vertical list of full-width cards (thumbnail + name + revenue chip + clients/area + asking price + "Contact" button)
- **Detail sheet** (tap card) — opens 78%-height bottom sheet with full image, price, seller card with stars, description, "Message" + "Make offer / Request rental" buttons

### 3. Quick Pools (`screens/quickpools.jsx`)

**Purpose:** Real-time map + list of available single-pool jobs in user's county.

**Layout:**

- Navy header with title "Quick Pools" + subtitle "All jobs in Broward County" + aqua "+" button (opens Post Quick Pool flow)
- **Notification-region indicator strip** in header:
  - Top: small "NOTIF. BY DAY" label
  - Shows comma-separated cities from notification preferences (truncated)
  - Shows "5/7 days active" counter
  - "Edit" button opens Region Editor sheet
- **Google-Maps-style map** (200px tall):
  - Light gray base, yellow primary roads, white minor roads, green parks, blue water
  - **Job pins** as Google-style teardrops with price label (`$45`, `?` for negotiable)
  - User's location: blue dot with concentric pulse
  - Top-left search hint pill, top-right zoom controls, bottom-right re-center
- **Info banner** (light blue): "Showing all jobs in **Broward County**. You're only **notified** for jobs in your configured cities and days."
- **Job count + tier indicator** (e.g. "5 jobs available • 🔒 Premium applies")
- **Job cards** (vertical list):
  - Tag chip (Applied, etc.) + time
  - Title + location/distance
  - Pool count, price (large blue) + "/pool" subtitle
  - Avatar of poster + name + star rating
  - Action button: Free = "🔒 Unlock"; Premium/Pro applied = "✓ Applied"; otherwise "Apply"
- **Detail sheet** (tap card) — 86%-height. Shows offer/pools/when block, condo access pills (gate code, doorman, dog — locked for Free), description, poster card, sticky CTA (Contact + Apply, or "Unlock to apply" for Free)

### 4. Work (`screens/work.jsx`)

**Purpose:** Three sub-views — Hiring, Technicians, Vacation.

**Layout:**

- Navy header with back + plus button
- **Sub-tab card** (overlapping header) — 3 pills: Hiring / Technicians / Vacation. Active = solid blue with shadow.

**Hiring sub-view:** Vertical list of job-posting cards (company name + icon, description, location + equipment-provided + CDL chips, pay, "Apply" button).

**Technicians sub-view:** Vertical list of tech profiles (avatar + name + rating, description, location + speciality + verified+jobs count, rate, "Message" + "Contact").

**Vacation sub-view:**

- **Profile-boost info card** — dark navy gradient, gold star icon, headline "Covering vacations boosts your profile", body explaining ratings/visibility benefit, chip "+ Visibility · + Reviews"
- **Going-on-vacation card** — aqua/blue gradient with calendar icon, "Post availability" button
- Segmented control: Posted ({n}) / Applied ({n})
- **Posted tab:** Cards for each vacation posting with open status, month, region, applicants count, pools-per-day, price, mini calendar grid showing selected days, "View applicants" + "Edit" buttons
- **Applied tab:** Cards showing the owner you applied to with accepted/awaiting status, mini calendar, "Chat" + "View schedule" / "Withdraw"
- **Post-vacation sheet** (92% height) — full flow:
  - Month picker (horizontal chips, all 12 months)
  - Calendar grid: tap to select days you'll be away
  - **"Region by weekday"** section — automatically appears for each weekday represented in your selected dates. For each weekday, pick **one** city (the region from which you accept coverage that day). E.g. you selected July 6 (Mon) and July 13 (Mon), the "Monday" row appears once and asks for a city.
  - Price (fixed $/pool or negotiable)

### 5. Profile (`screens/profile.jsx`)

**Purpose:** User profile and settings.

Standard profile: avatar, name, rating, tier badge, stats grid (jobs, listings, reviews), subscription card with upgrade CTA, settings list (notifications, payment methods, language, etc.).

### 6. Post Quick Pool flow (`screens/post.jsx`)

**Purpose:** Multi-step form for creating a Quick Pool listing. **Critical: each pool is an independent entry with its own location and type.**

**3 steps with progress bar:**

**Step 1 — Job info:** Title (required), Notes (optional), When date pills (Now / Today PM / Tomorrow / This week / Flexible / Custom; "Now" pill is red urgent style).

**Step 2 — Pools (the important one):**
- Heading: "Each pool, its own details"
- Body: "Each pool can be in a different city and type (house or condo)."
- For each pool, a **PoolItemCard**:
  - Header: numbered circle ("1", "2", …) + "Pool N" + "Remove" link (hidden if only 1 pool left)
  - "Location of this pool" — **single-city** autocomplete (one city only per pool). Resolved state shows aqua-filled pill with x to clear.
  - "Type" — 2-button selector: 🏠 Street House / 🏢 Condo
  - If Condo: aqua-tinted nested section with toggles for Gate code (+ code input if on), Doorman, Dog — each scoped to this pool only
- Bottom: dashed blue button "+ Add another pool"

**Step 3 — Price + summary:** Fixed/Negotiable seg, price input, summary card with per-pool breakdown listing each pool with its location and a "House"/"Condo" badge, total budget calculation.

### 7. Region Editor sheet (`brand.jsx` → `RegionEditorSheet`)

**Purpose:** User configures which cities they want notifications from on each weekday.

**Layout (92% sheet):**

- Header: title, description, close button
- Vertical list of **7 day cards** (Monday → Sunday)
- Each day card:
  - Header row: tinted weekday badge ("Mon" / blue if any cities selected, gray if none), full day name, summary of selected cities or "None — no notifications", right-side chevron
  - Tap to expand: county chip strip + 2-column grid of city checkboxes for that day
  - "Clear" button per day
- Sticky "Save" button at bottom

**Model:** `regionsByDay: { mon: ['Pompano Beach', 'Fort Lauderdale'], tue: ['Boca Raton'], … }`

### 8. Overlays (`screens/overlays.jsx`)

- **ChatSheet** — 86% height. Header with avatar + active status. Job context strip. Message bubbles. Sticky input bar with send button.
- **NotificationsSheet** — 72% height. List of notifications with category-colored circular icons (job/message/apply/rating). Unread items get blue-50 background and blue dot.
- **PaywallSheet** — 88% height. Crown icon header, Premium/Pro tier seg, big price card (Pro is dark gradient with "BEST VALUE" chip), feature comparison rows with check/x, big CTA "Start trial".
- **PostMenuSheet** — auto height. 6 action rows: Post Quick Pool / Sell equipment / Rent equipment / Sell route / Post vacation / Hire technician.

### 9. Tab Bar (`components.jsx` → `TabBar`)

5 tabs at the bottom. **Center tab (Quick Pools) is elevated:**

- 56×56 circle with aqua gradient (`--pg-aqua-500` → `--pg-aqua-700`)
- White-shadow ring (4px white), colored drop shadow
- Negative top margin of -22px so it sits above the bar
- Active state: scale 1.05, translate-Y -2px, stronger shadow
- Other 4 tabs: standard icon + label, blue when active

## Interactions & Behavior

- **Tab navigation** — bottom bar; tapping center "Quick Pools" jumps to that screen with the elevated animation feedback.
- **Sheet animations** — all sheets slide up from bottom with a 0.28s cubic-bezier ease-out. Tap backdrop or close button to dismiss.
- **Card tap** — `transform: scale(0.985)` on active for press feedback.
- **Search autocomplete** — single-city field in Post Quick Pool: dropdown shows up to 5 matches grouped by county, max 1ms `onMouseDown` to commit (avoid blur race).
- **Language switching** — globe pill cycles EN → PT → ES → EN. All strings live in `data.jsx` under `STRINGS[lang]`.
- **Premium gating** — three places enforce tier:
  1. **Quick Pools list/detail** — Free users see "Unlock" button instead of Apply, lock-icon overlay on condo access pills, paywall on tap.
  2. **Home → Today's Pool Jobs** — Only `tier === 'premium'` sees prices and can interact. Free + Pro see lock icon and "Premium" chip; tap opens paywall.
  3. **Quick Pools detail sheet** — Locked CTA "Unlock to apply" for Free; Contact button disabled.
- **Quick Pool job list scope** — shows ALL jobs in user's county; the user's `regionsByDay` map only controls which jobs trigger push notifications.
- **Post Quick Pool — independent pools:** Adding a pool spawns a new PoolItemCard with its own state object. Each card's location autocomplete, type selector, and condo toggles are scoped to that pool's object only. "Continue" disabled until every pool has a location.

## State Management

Root state lives in `app.jsx` → `App` component. Move this into your real state container (Redux / Zustand / SwiftUI `@StateObject` / etc.).

```
user: { name, tier: 'free'|'premium'|'pro', rating, reviews, regions, county }
lang: 'en'|'pt'|'es'
regionsByDay: { mon: [city...], tue: [city...], ..., sun: [city...] }
county: 'Broward'  // user's home county, from profile
tab: 'home'|'market'|'quick'|'work'|'profile'
// Overlay open flags: chatOpen, notifOpen, payOpen, postMenuOpen, postQPOpen, regionOpen
toast: string|null
```

Each screen receives a `ctx` object exposing user, lang, regionsByDay, county, tab-navigation function, and overlay-opening functions.

**Data fetching requirements** (not implemented in mocks — replace `QUICK_POOLS`, `EQUIPMENT`, `POOL_ROUTES`, `HIRING`, `TECHS`, `FEATURED`, `NOTIFICATIONS`, `VACATIONS_*` in `data.jsx`):

- `GET /quick-pools?county={county}` → all Quick Pool jobs in the user's county (Quick Pools screen list).
- `GET /quick-pools/today?regionsByDay={...}&day={today_weekday}` → filtered to "Today's Pool Jobs" feed on Home.
- `POST /quick-pools` body: `{ title, notes, when, pools: [{ location, poolType, gateCode, gateCodeVal, doorman, dog }], priceMode, price }` — each pool object stored independently.
- `GET /marketplace/equipment?mode=sell|rent&category={cat}&q={search}`
- `GET /marketplace/routes`
- `GET /work/hiring`, `/work/technicians`, `/work/vacations?status=posted|applied`
- `POST /work/vacations` body: `{ month, days: [int], price, regionsByWeekday: { mon: 'city', tue: 'city', ... } }`
- `PUT /user/preferences` body: `{ regionsByDay }` — saves notification config from Region Editor.
- `POST /chat/messages` — chat replies.
- `POST /billing/subscribe` — paywall conversion.

## Design Tokens

All tokens are defined in `tokens.css`. Reproduce them in your codebase's design-system file.

### Colors

| Token | OKLCH | Approx hex | Use |
|---|---|---|---|
| `--pg-navy-900` | `oklch(0.20 0.06 250)` | `#0e1733` | Darkest header |
| `--pg-blue-900` | `oklch(0.30 0.12 245)` | `#143169` | Deep navy text/bg |
| `--pg-blue-700` | `oklch(0.42 0.16 245)` | `#1f4ea5` | Strong blue text |
| `--pg-blue-600` | `oklch(0.50 0.18 240)` | `#2862c4` | Header gradient end |
| `--pg-blue-500` | `oklch(0.58 0.16 235)` | `#3a78d3` | **Primary** (buttons, links) |
| `--pg-blue-100` | `oklch(0.94 0.03 230)` | `#e1ecf7` | Light blue tint |
| `--pg-blue-50`  | `oklch(0.98 0.01 230)` | `#f4f8fd` | Faint blue bg |
| `--pg-aqua-700` | `oklch(0.55 0.13 180)` | `#1f8e93` | Aqua dark |
| `--pg-aqua-500` | `oklch(0.72 0.14 178)` | `#3dc4ca` | **Accent**, centered tab, success |
| `--pg-aqua-400` | `oklch(0.80 0.13 178)` | `#5fd6db` | Light aqua |
| `--pg-aqua-100` | `oklch(0.94 0.05 178)` | `#dff3f4` | Aqua bg tint |
| `--pg-ink-900` | `oklch(0.20 0.01 240)` | `#262c33` | Text |
| `--pg-ink-700` | `oklch(0.38 0.01 240)` | `#52585f` | Secondary text |
| `--pg-ink-500` | `oklch(0.56 0.01 240)` | `#7d838a` | Tertiary text |
| `--pg-ink-300` | `oklch(0.82 0.005 240)` | `#cbcdcf` | Borders strong |
| `--pg-ink-200` | `oklch(0.91 0.004 240)` | `#e4e5e7` | Borders soft |
| `--pg-ink-100` | `oklch(0.96 0.003 240)` | `#f1f1f2` | Soft bg |
| `--pg-bg` | `oklch(0.985 0.003 240)` | `#fafafa` | Screen bg |
| `--pg-danger` | `oklch(0.62 0.20 25)` | `#dd4f2a` | Urgent |
| `--pg-warn` | `oklch(0.74 0.16 60)` | `#e89e3d` | Warning |
| `--pg-success` | `oklch(0.68 0.14 155)` | `#4cb47e` | Success |

### Typography

- **Body / UI:** Inter (Google Fonts, weights 400/500/600/700/800)
- **Display (headings, prices, numerals):** Sora (weights 400/600/700/800)
- **Serif (rare accent):** Instrument Serif
- **Mono (labels in placeholders):** ui-monospace, "SF Mono"

Common sizes: 10/11/12/13/14/15/16/17/18/20/22/26/30/36px. Letter-spacing on display sizes is tight (`-0.01em` to `-0.025em`).

### Spacing

8px-based scale: 4, 6, 8, 10, 12, 14, 18, 24, 28, 32, 40, 54, 80px. Screen edge padding is `18px`. Card padding is `14px` (compact) or `18px` (default).

### Radii

- `--pg-r-sm: 8px`
- `--pg-r-md: 12px`
- `--pg-r-lg: 16px`
- `--pg-r-xl: 22px`
- Full pill: `999px`
- Avatars / status badges: `50%`

### Shadows

- `--pg-shadow-1`: `0 1px 2px rgba(15,30,60,0.05), 0 1px 1px rgba(15,30,60,0.04)` (cards)
- `--pg-shadow-2`: `0 4px 16px rgba(15,30,60,0.07), 0 1px 2px rgba(15,30,60,0.04)` (active cards, sheets)
- `--pg-shadow-3`: `0 12px 32px rgba(15,30,60,0.12), 0 2px 6px rgba(15,30,60,0.05)` (paywall, modal hero)
- Colored shadows for branded buttons: `0 6px 20px oklch(0.58 0.16 235 / 0.30)` (primary blue button), `0 6px 14px oklch(0.72 0.14 178 / 0.45)` (aqua / center tab)

## Assets

- **Icons** — all icons are inline SVG defined in `components.jsx` → `Icon` object (`bell`, `bolt`, `cal`, `cart`, `chev`, `check`, `clock`, `crown`, `dog`, `filter`, `globe`, `heart`, `home`, `key`, `lock`, `more`, `msg`, `pin`, `plus`, `pool`, `search`, `shield`, `star`, `user`, `x`, `arrow`, `briefcase`). 1.8 stroke weight, round line caps. Replace with your platform's icon set (SF Symbols on iOS, Material on Android) but keep weights and visual style consistent.
- **Equipment imagery** — `brand.jsx` → `EquipImg` generates per-category placeholder thumbnails as inline SVG glyphs (pump/filter/vacuum/heater/tool/route). Replace with real product photos.
- **Wordmark** — pure CSS+SVG composition; can be exported and exposed as a single SVG asset.
- **Avatars** — initials on colored backgrounds (`components.jsx` → `Avatar`). Replace with real user photos when present.
- **Status bar / device frame** — for HTML mock only (`ios-frame.jsx`). Not needed in real iOS app.

## Files

Bundled in `source/`:

```
PoolGuyPro.html          — root HTML; loads React, Babel, and all JSX modules
tokens.css               — CSS variables for colors, type, shadow, radii + utility classes
app.jsx                  — root <App />, state, tab routing, overlay management, Tweaks panel
brand.jsx                — Wordmark, NavyBar, EquipImg, FL_COUNTIES, RegionEditorSheet
components.jsx           — Icon library, Avatar, Stars, Sheet, IconButton, TabBar, LangPill
data.jsx                 — STRINGS (EN/PT/ES), QUICK_POOLS, EQUIPMENT, POOL_ROUTES, HIRING, TECHS, FEATURED, NOTIFICATIONS, VACATIONS_*
ios-frame.jsx            — iOS status bar mock
tweaks-panel.jsx         — design-system tweaks panel (dev only, remove in production)
screens/
  home.jsx               — Home screen
  marketplace.jsx        — Marketplace + detail sheet
  quickpools.jsx         — Quick Pools map + list + detail
  work.jsx               — Hiring / Technicians / Vacation panels + post-vacation sheet
  profile.jsx            — Profile
  post.jsx               — Post Quick Pool 3-step form (per-pool item cards)
  overlays.jsx           — ChatSheet, NotificationsSheet, PaywallSheet, PostMenuSheet, Toast
```

To preview the design locally, open `PoolGuyPro.html` in a modern browser. The Babel in-browser transpiler will compile the JSX on the fly.

## Notes for Implementation

1. **Premium gating logic** must be enforced server-side too — don't just hide UI. The Today's Pool Jobs Premium check should reject API requests from non-premium users that try to fetch contact info.
2. **Region Editor model change** — earlier prototypes used separate `regions: string[]` + `days: weekday[]`. Current model is `regionsByDay: Record<weekday, string[]>` which lets users pick different cities per day. Make sure your backend schema matches.
3. **Each pool in a Quick Pool listing is independent.** The DB schema should be `quick_pool_listings` (1) → `quick_pool_pools` (many), each with its own location, type, gate code, doorman, dog. Do not flatten location into a comma list on the parent.
4. **Florida counties** are hard-coded in `brand.jsx` → `FL_COUNTIES`. In production, fetch this from a `/cities` endpoint and key by ZIP/state.
5. **Vacation profile boost** — when a tech accepts and completes a vacation coverage, server should bump their profile rank and surface those reviews preferentially in technician search.
6. **i18n** — strings are flat key/value per language in `data.jsx`. Migrate to your platform's standard localization (e.g. `Localizable.strings` on iOS, `intl` JSON files on RN).
7. **Tab bar elevated center button** — on iOS, you can fake this with a custom `UITabBar` subclass or use SwiftUI's `TabView` with a manually-placed overlay button. Pay attention to safe-area insets so the elevated button doesn't get clipped on devices with home indicator.
