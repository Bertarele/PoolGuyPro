// app.jsx — root, tab routing, overlays

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "tier": "free",
  "lang": "en",
  "density": "regular",
  "showDevControls": true
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [tab, setTab] = React.useState('home');
  const [user, setUser] = React.useState({
    name:'Lucas Mendes', tier: t.tier, rating: 4.9, reviews: 128,
    regions:['Broward','Weston','Plantation'],
  });
  const [lang, setLang] = React.useState(t.lang);
  // Per-weekday region preferences for notifications
  const [regionsByDay, setRegionsByDay] = React.useState({
    mon: ['Pompano Beach','Fort Lauderdale'],
    tue: ['Deerfield Beach','Boca Raton'],
    wed: ['Pompano Beach','Fort Lauderdale'],
    thu: ['Plantation','Davie'],
    fri: ['Weston','Plantation'],
    sat: [],
    sun: [],
  });
  // User's home county (from profile) — Quick Pools shows ALL jobs in this county
  const [county] = React.useState('Broward');
  // overlays
  const [chatOpen, setChatOpen]   = React.useState(false);
  const [notifOpen, setNotifOpen] = React.useState(false);
  const [payOpen, setPayOpen]     = React.useState(false);
  const [postMenuOpen, setPostMenuOpen] = React.useState(false);
  const [postQPOpen, setPostQPOpen]     = React.useState(false);
  const [regionOpen, setRegionOpen]     = React.useState(false);
  const [toast, setToast] = React.useState(null);

  // Sync tweak → state
  React.useEffect(()=>{ setUser(u=>({...u, tier:t.tier})); }, [t.tier]);
  React.useEffect(()=>{ setLang(t.lang); }, [t.lang]);

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(()=>setToast(null), 2400);
  };

  const ctx = {
    user, setUser: (u) => {
      const next = typeof u === 'function' ? u(user) : u;
      setUser(next);
      if (next.tier !== t.tier) setTweak('tier', next.tier);
    },
    lang, setLang: (l) => { setLang(l); setTweak('lang', l); },
    regionsByDay, setRegionsByDay, county,
    goTab: setTab,
    openChat:          () => setChatOpen(true),
    openNotifications: () => setNotifOpen(true),
    openPaywall:       () => setPayOpen(true),
    openPostMenu:      () => setPostMenuOpen(true),
    openPost:          () => setPostQPOpen(true),
    openRegionEditor:  () => setRegionOpen(true),
  };

  return (
    <div style={{
      width:402, height:874, position:'relative', overflow:'hidden',
      borderRadius:48, background:'var(--pg-bg)',
    }}>
      {/* Screen content */}
      <div style={{
        position:'absolute', inset:0,
        paddingTop:54, // for status bar
        overflow:'auto',
      }}>
        {tab === 'home'    && <HomeScreen ctx={ctx}/>}
        {tab === 'market'  && <MarketplaceScreen ctx={ctx}/>}
        {tab === 'quick'   && <QuickPoolsScreen ctx={ctx}/>}
        {tab === 'work'    && <WorkScreen ctx={ctx}/>}
        {tab === 'profile' && <ProfileScreen ctx={ctx}/>}
      </div>

      {/* Status bar overlay — all screens have dark headers */}
      <div style={{
        position:'absolute', top:0, left:0, right:0, zIndex:25,
        background: 'transparent',
      }}>
        <IOSStatusBar dark={true} />
      </div>

      {/* Tab bar */}
      <TabBar tab={tab} setTab={setTab} lang={lang}/>

      {/* Overlays */}
      <ChatSheet open={chatOpen} onClose={()=>setChatOpen(false)} lang={lang}/>
      <NotificationsSheet open={notifOpen} onClose={()=>setNotifOpen(false)} lang={lang}/>
      <PaywallSheet open={payOpen} onClose={()=>setPayOpen(false)} setUser={ctx.setUser} lang={lang}/>
      <PostMenuSheet open={postMenuOpen} onClose={()=>setPostMenuOpen(false)}
        onPickQuickPool={()=>setPostQPOpen(true)} lang={lang}/>
      <Sheet open={postQPOpen} onClose={()=>setPostQPOpen(false)} height="92%">
        <PostQuickPool
          lang={lang}
          onClose={()=>setPostQPOpen(false)}
          onSubmit={()=>{
            setPostQPOpen(false);
            showToast(STRINGS[lang].toastPosted);
            setTab('quick');
          }}
        />
      </Sheet>
      <Toast message={toast}/>

      {/* Region editor */}
      <RegionEditorSheet
        open={regionOpen} onClose={()=>setRegionOpen(false)} lang={lang}
        regionsByDay={regionsByDay} setRegionsByDay={setRegionsByDay}
        county={county}
      />

      {/* Home indicator */}
      <div style={{
        position:'absolute', bottom:0, left:0, right:0, zIndex:60,
        height:34, display:'flex', justifyContent:'center', alignItems:'flex-end',
        paddingBottom:8, pointerEvents:'none',
      }}>
        <div style={{width:139, height:5, borderRadius:100, background:'rgba(0,0,0,0.25)'}}/>
      </div>

      {/* Tweaks */}
      <TweaksPanel>
        <TweakSection label="Subscription tier"/>
        <TweakRadio value={t.tier} options={['free','premium','pro']}
          onChange={v=>{ setTweak('tier', v); }}/>
        <div style={{fontSize:10, color:'rgba(41,38,27,.55)', lineHeight:1.4, marginTop:-4}}>
          Free = Quick Pools locked. Premium/PRO unlock apply + contact.
        </div>

        <TweakSection label="Language"/>
        <TweakRadio value={t.lang} options={['en','pt','es']}
          onChange={v=>setTweak('lang', v)}/>

        <TweakSection label="Quick jumps"/>
        <TweakButton onClick={()=>{ setTab('quick'); }}>Open Quick Pools</TweakButton>
        <TweakButton onClick={()=>setPostMenuOpen(true)}>Open post menu</TweakButton>
        <TweakButton onClick={()=>setPostQPOpen(true)}>Open Post Quick Pool form</TweakButton>
        <TweakButton onClick={()=>setChatOpen(true)}>Open chat</TweakButton>
        <TweakButton onClick={()=>setPayOpen(true)}>Open paywall</TweakButton>
        <TweakButton onClick={()=>setNotifOpen(true)}>Open notifications</TweakButton>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
