// brand.jsx — wordmark, illustrative product imagery, region editor

// ── Brand wordmark ────────────────────────────────────────────
function Wordmark({ size='md', onDark=false, subtitle }) {
  const scale = size === 'lg' ? 1.25 : size === 'sm' ? 0.82 : 1;
  const markSize = 36 * scale;
  const wordSize = 22 * scale;
  const textColor = onDark ? '#fff' : 'var(--pg-ink-900)';
  const guySoft  = onDark ? 'rgba(255,255,255,0.62)' : 'var(--pg-ink-500)';
  const proColor = onDark ? 'var(--pg-aqua-400)' : 'var(--pg-aqua-700)';

  return (
    <div style={{display:'flex', alignItems:'center', gap: 10*scale, minWidth:0}}>
      {/* Mark — pill shape with water drop */}
      <div style={{
        width:markSize, height:markSize, borderRadius: markSize*0.30, position:'relative',
        background: onDark
          ? 'rgba(255,255,255,0.10)'
          : 'linear-gradient(150deg, var(--pg-navy-900) 0%, var(--pg-blue-700) 100%)',
        border: onDark ? '0.5px solid rgba(255,255,255,0.16)' : 'none',
        boxShadow: onDark ? 'none' : '0 3px 10px oklch(0.30 0.12 245 / 0.30)',
        overflow:'hidden', flexShrink:0,
        display:'flex', alignItems:'center', justifyContent:'center',
      }}>
        <svg viewBox="0 0 24 24" width="52%" height="52%">
          <path d="M12 3 C 7 9, 5 13, 5 16 A 7 7 0 0 0 19 16 C 19 13, 17 9, 12 3 Z" fill="#fff"/>
        </svg>
      </div>

      {/* Wordmark */}
      <div style={{display:'flex', flexDirection:'column', minWidth:0, lineHeight:1}}>
        <div style={{display:'flex', alignItems:'baseline', gap:0}}>
          <span style={{
            fontFamily:'var(--pg-font-display)',
            fontSize: wordSize, fontWeight:700, letterSpacing:'-0.025em',
            color: textColor,
          }}>Pool</span>
          <span style={{
            fontFamily:'var(--pg-font-display)',
            fontSize: wordSize, fontWeight:400, letterSpacing:'-0.02em',
            color: guySoft,
          }}>Guy</span>
          <span style={{
            fontFamily:'var(--pg-font-display)',
            fontSize: wordSize*0.40, fontWeight:700, color: proColor,
            marginLeft: 6*scale, letterSpacing:'0.10em',
            transform:`translateY(-${wordSize*0.35}px)`, display:'inline-block',
          }}>PRO</span>
        </div>
        {subtitle && (
          <div style={{
            fontSize: wordSize*0.41, fontWeight:400, marginTop:5,
            color: onDark ? 'rgba(255,255,255,0.7)' : 'var(--pg-ink-500)',
            letterSpacing:'-0.005em', lineHeight:1.3, maxWidth: 230*scale,
          }}>{subtitle}</div>
        )}
      </div>
    </div>
  );
}

// ── Dark navy app bar (used on Marketplace, Work, etc.) ──────
function NavyBar({ title, leftBack, onBack, right, children }) {
  return (
    <div style={{
      background:`linear-gradient(180deg, var(--pg-navy-900) 0%, var(--pg-blue-600) 100%)`,
      color:'#fff', padding:'10px 18px 18px', position:'relative', overflow:'hidden',
    }}>
      <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', gap:10, minHeight:42}}>
        <div style={{display:'flex', alignItems:'center', gap:10, flex:1, minWidth:0}}>
          {leftBack && (
            <button onClick={onBack} style={{
              border:'none', background:'rgba(255,255,255,0.10)', width:36, height:36,
              borderRadius:'50%', cursor:'pointer', color:'#fff',
              display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0,
            }}>{Icon.chev(18, '#fff', 'left')}</button>
          )}
          {typeof title === 'string'
            ? <h1 style={{margin:0, fontFamily:'var(--pg-font-display)', fontSize:22, fontWeight:700, letterSpacing:'-0.02em'}}>{title}</h1>
            : title}
        </div>
        <div style={{display:'flex', alignItems:'center', gap:8}}>{right}</div>
      </div>
      {children}
    </div>
  );
}

// ── Equipment imagery (illustrative placeholders by category) ─
function EquipImg({ category, height=108, label, dark=false }) {
  const conf = {
    Pumps:   { bg:'linear-gradient(150deg, oklch(0.94 0.05 230) 0%, oklch(0.82 0.10 235) 100%)',
               accent:'oklch(0.50 0.16 245)', stroke:'oklch(0.40 0.16 245)', label:'PUMP' },
    Filters: { bg:'linear-gradient(150deg, oklch(0.94 0.05 178) 0%, oklch(0.82 0.10 175) 100%)',
               accent:'oklch(0.50 0.13 178)', stroke:'oklch(0.40 0.13 178)', label:'FILTER' },
    Vacuum:  { bg:'linear-gradient(150deg, oklch(0.94 0.04 250) 0%, oklch(0.78 0.07 255) 100%)',
               accent:'oklch(0.30 0.12 250)', stroke:'oklch(0.30 0.12 250)', label:'VACUUM' },
    Heaters: { bg:'linear-gradient(150deg, oklch(0.95 0.06 70) 0%, oklch(0.82 0.13 50) 100%)',
               accent:'oklch(0.45 0.16 45)', stroke:'oklch(0.40 0.15 45)', label:'HEATER' },
    Tools:   { bg:'linear-gradient(150deg, oklch(0.95 0.02 240) 0%, oklch(0.85 0.04 240) 100%)',
               accent:'oklch(0.40 0.05 240)', stroke:'oklch(0.35 0.04 240)', label:'TOOL' },
    Routes:  { bg:'linear-gradient(155deg, var(--pg-aqua-100) 0%, var(--pg-blue-100) 100%)',
               accent:'var(--pg-blue-700)', stroke:'var(--pg-blue-700)', label:'ROUTE' },
  };
  const c = conf[category] || conf.Tools;

  return (
    <div style={{
      height, background: c.bg, position:'relative', overflow:'hidden',
      display:'flex', alignItems:'center', justifyContent:'center',
    }}>
      {/* SVG glyph per category */}
      <svg viewBox="0 0 100 100" width="58%" height="58%" style={{opacity:0.82}}>
        {category === 'Pumps' && (
          <g fill="none" stroke={c.stroke} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="50" cy="50" r="26" fill={c.accent} fillOpacity="0.18"/>
            <circle cx="50" cy="50" r="14" fill={c.accent} fillOpacity="0.35"/>
            <circle cx="50" cy="50" r="4" fill={c.stroke}/>
            <path d="M50 24 L50 16 M24 50 L16 50 M76 50 L84 50 M50 76 L50 84"/>
          </g>
        )}
        {category === 'Filters' && (
          <g fill="none" stroke={c.stroke} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
            <rect x="32" y="22" width="36" height="56" rx="6" fill={c.accent} fillOpacity="0.20"/>
            <path d="M32 38 L68 38 M32 50 L68 50 M32 62 L68 62" opacity="0.6"/>
            <path d="M44 22 L44 14 L56 14 L56 22" />
            <path d="M46 78 L46 86 L54 86 L54 78"/>
          </g>
        )}
        {category === 'Vacuum' && (
          <g fill="none" stroke={c.stroke} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="50" cy="62" r="20" fill={c.accent} fillOpacity="0.22"/>
            <path d="M50 42 Q50 26 35 22"/>
            <circle cx="33" cy="22" r="5" fill={c.accent} fillOpacity="0.4"/>
            <ellipse cx="50" cy="78" rx="14" ry="3" fill={c.stroke} opacity="0.35"/>
          </g>
        )}
        {category === 'Heaters' && (
          <g fill="none" stroke={c.stroke} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
            <rect x="20" y="32" width="60" height="40" rx="5" fill={c.accent} fillOpacity="0.22"/>
            <path d="M30 44 Q34 38 38 44 T 46 44" opacity="0.7"/>
            <path d="M54 44 Q58 38 62 44 T 70 44" opacity="0.7"/>
            <circle cx="68" cy="60" r="4" fill={c.accent} fillOpacity="0.6"/>
            <path d="M28 32 L28 24 M72 32 L72 24"/>
          </g>
        )}
        {category === 'Tools' && (
          <g fill="none" stroke={c.stroke} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M22 78 L78 22"/>
            <ellipse cx="22" cy="78" rx="9" ry="5" transform="rotate(-45 22 78)" fill={c.accent} fillOpacity="0.3"/>
            <rect x="68" y="14" width="18" height="14" rx="2" transform="rotate(45 77 21)" fill={c.accent} fillOpacity="0.3"/>
          </g>
        )}
        {category === 'Routes' && (
          <g fill="none" stroke={c.stroke} strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 80 Q30 50 50 60 T 82 30" strokeDasharray="4 4"/>
            <circle cx="18" cy="80" r="6" fill={c.accent} fillOpacity="0.4"/>
            <circle cx="50" cy="60" r="5" fill={c.accent} fillOpacity="0.4"/>
            <circle cx="82" cy="30" r="6" fill={c.accent} fillOpacity="0.4"/>
          </g>
        )}
      </svg>
      {label && (
        <span style={{
          position:'absolute', bottom:8, right:10, fontSize:9, fontWeight:700,
          color: c.accent, letterSpacing:'0.08em', opacity:0.65,
          fontFamily:'ui-monospace, "SF Mono", monospace',
        }}>{label || c.label}</span>
      )}
    </div>
  );
}

// ── Region editor sheet ───────────────────────────────────────
const FL_COUNTIES = {
  'Broward':      ['Fort Lauderdale','Hollywood','Pembroke Pines','Davie','Plantation','Sunrise','Coral Springs','Weston','Pompano Beach','Deerfield Beach'],
  'Miami-Dade':   ['Miami','Miami Beach','Coral Gables','Doral','Hialeah','Kendall','Homestead','Pinecrest','Aventura','Cutler Bay'],
  'Palm Beach':   ['West Palm Beach','Boca Raton','Delray Beach','Boynton Beach','Jupiter','Wellington','Lake Worth','Royal Palm Beach'],
  'Orange':       ['Orlando','Winter Park','Apopka','Ocoee','Maitland'],
  'Hillsborough': ['Tampa','Brandon','Plant City','Riverview'],
  'Pinellas':     ['St. Petersburg','Clearwater','Largo','Pinellas Park'],
};

function RegionEditorSheet({ open, onClose, lang='en', regionsByDay, setRegionsByDay, county }) {
  const t = STRINGS[lang];
  const [openDay, setOpenDay] = React.useState('mon');
  const [activeCounty, setActiveCounty] = React.useState(county || 'Broward');

  const dayKeys   = ['mon','tue','wed','thu','fri','sat','sun'];
  const dayShort  = lang==='pt'?['Seg','Ter','Qua','Qui','Sex','Sáb','Dom']
                  : lang==='es'?['Lun','Mar','Mié','Jue','Vie','Sáb','Dom']
                  : ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const dayFull   = lang==='pt'?['Segunda-feira','Terça-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sábado','Domingo']
                  : lang==='es'?['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo']
                  : ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];

  const toggleCityForDay = (day, city) => {
    setRegionsByDay(prev => {
      const cur = prev[day] || [];
      const next = cur.includes(city) ? cur.filter(c => c !== city) : [...cur, city];
      return { ...prev, [day]: next };
    });
  };
  const clearDay = (day) => {
    setRegionsByDay(prev => ({ ...prev, [day]: [] }));
  };

  const head = {
    title: lang==='pt'?'Regiões por dia':lang==='es'?'Regiones por día':'Regions by day',
    desc: lang==='pt'
      ? 'Para cada dia da semana, escolha as cidades onde você quer receber notificações de trabalho.'
      : lang==='es'
        ? 'Para cada día de la semana, elige las ciudades donde quieres recibir notificaciones de trabajo.'
        : 'For each weekday, choose the cities where you want to receive job notifications.',
    countyT: lang==='pt'?'Condado':lang==='es'?'Condado':'County',
    citiesT: lang==='pt'?'Cidades':lang==='es'?'Ciudades':'Cities',
    selected: lang==='pt'?'cidades':lang==='es'?'ciudades':'cities',
    none: lang==='pt'?'Nenhuma — sem notificações':lang==='es'?'Ninguna — sin notificaciones':'None — no notifications',
    save: lang==='pt'?'Salvar':lang==='es'?'Guardar':'Save',
    clearLbl: lang==='pt'?'Limpar':lang==='es'?'Limpiar':'Clear',
    pickCities: lang==='pt'?'Escolha as cidades':lang==='es'?'Elige las ciudades':'Pick cities',
  };

  return (
    <Sheet open={open} onClose={onClose} height="92%">
      <div style={{display:'flex', flexDirection:'column', height:'100%'}}>
        {/* Header */}
        <div style={{padding:'4px 18px 14px', borderBottom:'0.5px solid var(--pg-ink-200)'}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6}}>
            <h2 style={{margin:0, fontSize:18, fontWeight:700, letterSpacing:'-0.02em'}}>{head.title}</h2>
            <button onClick={onClose} style={{
              border:'none', background:'var(--pg-ink-100)', width:30, height:30,
              borderRadius:'50%', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
            }}>{Icon.x(16, 'var(--pg-ink-700)')}</button>
          </div>
          <div style={{fontSize:12, color:'var(--pg-ink-500)', lineHeight:1.4}}>{head.desc}</div>
        </div>

        {/* Scroll body */}
        <div style={{flex:1, overflow:'auto', padding:'12px 18px 0'}}>
          <div style={{display:'flex', flexDirection:'column', gap:8}}>
            {dayKeys.map((dk, i) => {
              const cities = regionsByDay[dk] || [];
              const isOpen = openDay === dk;
              return (
                <div key={dk} className="pg-card" style={{padding:0, overflow:'hidden'}}>
                  <button onClick={()=>setOpenDay(isOpen ? null : dk)} style={{
                    display:'flex', alignItems:'center', gap:12, padding:'12px 14px',
                    border:'none', background:'transparent', width:'100%', cursor:'pointer',
                    textAlign:'left', fontFamily:'inherit',
                  }}>
                    <div style={{
                      width:42, height:42, borderRadius:11,
                      background: cities.length>0 ? 'var(--pg-blue-500)' : 'var(--pg-ink-100)',
                      color: cities.length>0 ? '#fff' : 'var(--pg-ink-500)',
                      display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0,
                      fontFamily:'var(--pg-font-display)', fontSize:13, fontWeight:700, letterSpacing:'-0.01em',
                      transition:'all .15s ease',
                    }}>{dayShort[i]}</div>
                    <div style={{flex:1, minWidth:0}}>
                      <div style={{fontSize:14, fontWeight:600, color:'var(--pg-ink-900)'}}>{dayFull[i]}</div>
                      <div style={{fontSize:12, color: cities.length>0 ? 'var(--pg-aqua-700)' : 'var(--pg-ink-500)', marginTop:2, lineHeight:1.35,
                        display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical', overflow:'hidden'}}>
                        {cities.length === 0 ? head.none : cities.join(' · ')}
                      </div>
                    </div>
                    <div style={{transform: isOpen ? 'rotate(90deg)' : 'rotate(0)', transition:'transform .2s ease', flexShrink:0}}>
                      {Icon.chev(16, 'var(--pg-ink-500)')}
                    </div>
                  </button>

                  {isOpen && (
                    <div style={{padding:'4px 14px 14px', borderTop:'0.5px solid var(--pg-ink-200)'}}>
                      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', margin:'10px 0 8px'}}>
                        <div style={{fontSize:10, color:'var(--pg-ink-500)', fontWeight:700, letterSpacing:'0.06em'}}>
                          {head.pickCities.toUpperCase()}
                        </div>
                        {cities.length > 0 && (
                          <button onClick={()=>clearDay(dk)} style={{
                            border:'none', background:'transparent', color:'var(--pg-ink-500)',
                            fontSize:11, fontWeight:600, cursor:'pointer', padding:'2px 6px',
                          }}>{head.clearLbl}</button>
                        )}
                      </div>
                      <div className="pg-scroll-x" style={{display:'flex', gap:6, marginLeft:-14, marginRight:-14, padding:'0 14px 6px'}}>
                        {Object.keys(FL_COUNTIES).map(c => (
                          <button key={c} onClick={()=>setActiveCounty(c)} className={`pg-chip ${activeCounty===c?'pg-chip-on':''}`} style={{fontSize:11, padding:'5px 10px'}}>
                            {c}
                          </button>
                        ))}
                      </div>
                      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:6, marginTop:8}}>
                        {FL_COUNTIES[activeCounty].map(city => {
                          const on = cities.includes(city);
                          return (
                            <button key={city} onClick={()=>toggleCityForDay(dk, city)} style={{
                              display:'flex', alignItems:'center', gap:7, padding:'9px 10px',
                              background: on ? 'var(--pg-aqua-100)' : 'var(--pg-white)',
                              border:'1px solid ' + (on ? 'var(--pg-aqua-400)' : 'var(--pg-ink-200)'),
                              borderRadius:9, cursor:'pointer', textAlign:'left', fontFamily:'inherit',
                              transition:'all .12s ease', minWidth:0,
                            }}>
                              <div style={{
                                width:16, height:16, borderRadius:4, flexShrink:0,
                                background: on ? 'var(--pg-aqua-500)' : 'transparent',
                                border:'1.5px solid ' + (on ? 'var(--pg-aqua-500)' : 'var(--pg-ink-300)'),
                                display:'flex', alignItems:'center', justifyContent:'center',
                              }}>
                                {on && Icon.check(10, '#fff')}
                              </div>
                              <span style={{flex:1, fontSize:12, fontWeight: on?600:500,
                                color: on?'var(--pg-aqua-700)':'var(--pg-ink-900)',
                                whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>
                                {city}
                              </span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
          <div style={{height:14}}/>
        </div>

        {/* Save */}
        <div style={{padding:'12px 18px 18px', borderTop:'0.5px solid var(--pg-ink-200)', background:'#fff'}}>
          <button onClick={onClose} className="pg-btn pg-btn-primary" style={{width:'100%', height:50, fontSize:15}}>
            {head.save}
          </button>
        </div>
      </div>
    </Sheet>
  );
}

Object.assign(window, { Wordmark, NavyBar, EquipImg, FL_COUNTIES, RegionEditorSheet });
