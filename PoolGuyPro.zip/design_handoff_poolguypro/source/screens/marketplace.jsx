// marketplace.jsx — navy header + dual seg + distance + categories

function MarketplaceScreen({ ctx }) {
  const { lang, openChat, openPostMenu, goTab } = ctx;
  const t = STRINGS[lang];
  // Single filter: buy | rent | routes — simpler than dual segs
  const [view, setView] = React.useState('buy');
  const [cat, setCat] = React.useState('All');
  const [q, setQ] = React.useState('');
  const [selected, setSelected] = React.useState(null);

  const catLabels = { All:{en:'All',pt:'Todos',es:'Todos'}, Pumps:{en:'Pumps',pt:'Bombas',es:'Bombas'},
    Filters:{en:'Filters',pt:'Filtros',es:'Filtros'}, Vacuum:{en:'Vacuum',pt:'Aspiradores',es:'Aspiradores'},
    Heaters:{en:'Heaters',pt:'Aquecedores',es:'Calentadores'}, Tools:{en:'Tools',pt:'Hastes',es:'Herramientas'} };
  const cats = Object.keys(catLabels);

  const isEquipment = view === 'buy' || view === 'rent';
  const mode = view === 'rent' ? 'rent' : 'sell';

  const list = isEquipment
    ? EQUIPMENT.filter(e =>
        e.mode === mode &&
        (cat === 'All' || e.category === cat) &&
        (q === '' || e.name.toLowerCase().includes(q.toLowerCase())))
    : POOL_ROUTES;

  const tabIcons = {
    buy:    (s,c)=> Icon.cart(s, c),
    rent:   (s,c)=> Icon.key(s, c),
    routes: (s,c)=> Icon.pin(s, c),
  };
  const tabLabels = {
    buy:    lang==='pt'?'Comprar':lang==='es'?'Comprar':'Buy',
    rent:   lang==='pt'?'Alugar':lang==='es'?'Rentar':'Rent',
    routes: lang==='pt'?'Rotas':lang==='es'?'Rutas':'Routes',
  };
  const tabSubs = {
    buy:    lang==='pt'?'Equipamentos à venda':lang==='es'?'Equipo en venta':'Equipment for sale',
    rent:   lang==='pt'?'Equipamentos para alugar':lang==='es'?'Equipo para rentar':'Equipment to rent',
    routes: lang==='pt'?'Rotas à venda':lang==='es'?'Rutas en venta':'Routes for sale',
  };

  return (
    <div className="pg-screen" style={{paddingBottom:110}}>
      <NavyBar
        title={t.marketplace}
        leftBack onBack={()=>goTab('home')}
        right={
          <button onClick={openPostMenu} className="pg-press" style={{
            width:38, height:38, borderRadius:'50%', border:'none', cursor:'pointer',
            background:'rgba(255,255,255,0.14)', border:'0.5px solid rgba(255,255,255,0.18)',
            color:'#fff', display:'flex', alignItems:'center', justifyContent:'center',
          }} aria-label="New listing">{Icon.plus(20, '#fff')}</button>
        }
      />

      <div style={{padding:'0 18px 16px'}}>
        {/* Filter strip card overlapping header */}
        <div className="pg-card" style={{padding:'12px', marginTop:-6, display:'flex', flexDirection:'column', gap:12}}>
          {/* 3-option visual segmented control with icons */}
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:6}}>
            {['buy','rent','routes'].map(v => {
              const on = view === v;
              return (
                <button key={v} onClick={()=>{ setView(v); setCat('All'); }} style={{
                  display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:4,
                  padding:'10px 6px', borderRadius:11, border:'none', cursor:'pointer',
                  background: on ? 'var(--pg-blue-500)' : 'var(--pg-ink-100)',
                  color: on ? '#fff' : 'var(--pg-ink-700)',
                  fontFamily:'inherit',
                  transition:'all .15s ease',
                  boxShadow: on ? '0 4px 10px oklch(0.58 0.16 235 / 0.30)' : 'none',
                }}>
                  <div style={{
                    width:28, height:28, borderRadius:'50%',
                    background: on ? 'rgba(255,255,255,0.18)' : 'var(--pg-white)',
                    display:'flex', alignItems:'center', justifyContent:'center',
                  }}>{tabIcons[v](15, on ? '#fff' : 'var(--pg-blue-700)')}</div>
                  <span style={{fontSize:13, fontWeight:700, letterSpacing:'-0.005em'}}>{tabLabels[v]}</span>
                  <span style={{fontSize:9.5, opacity:0.75, lineHeight:1.1, textAlign:'center'}}>{tabSubs[v]}</span>
                </button>
              );
            })}
          </div>

          {isEquipment && (
            <>
              {/* Search */}
              <div className="pg-search">
                {Icon.search(18)}
                <input placeholder={t.search} value={q} onChange={e=>setQ(e.target.value)}/>
              </div>

              {/* Category chips */}
              <div className="pg-scroll-x" style={{display:'flex', gap:8, marginLeft:-12, marginRight:-12, padding:'2px 12px'}}>
                {cats.map(c => {
                  const on = cat===c;
                  return (
                    <button key={c} className={`pg-chip ${on?'pg-chip-on':''}`} onClick={()=>setCat(c)} style={{padding:'7px 12px'}}>
                      {tr(catLabels[c], lang)}
                    </button>
                  );
                })}
              </div>
            </>
          )}
        </div>

        {/* Listings */}
        {isEquipment && (
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginTop:14}}>
            {list.map(e => (
              <button key={e.id} className="pg-card pg-card-tap" onClick={()=>setSelected(e)} style={{
                border:'none', textAlign:'left', cursor:'pointer', overflow:'hidden', padding:0,
              }}>
                <EquipImg category={e.category} height={120}/>
                <div style={{padding:'11px 12px 12px'}}>
                  <div style={{display:'flex', alignItems:'flex-start', gap:6}}>
                    <span style={{flex:1, fontSize:13.5, fontWeight:600, letterSpacing:'-0.01em', lineHeight:1.25,
                      display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical', overflow:'hidden'}}>{e.name}</span>
                    <span className="pg-chip" style={{padding:'2px 7px', fontSize:10, background:'var(--pg-blue-100)', color:'var(--pg-blue-700)', borderColor:'transparent', flexShrink:0}}>
                      {tr(e.condition, lang).toLowerCase()}
                    </span>
                  </div>
                  <div style={{fontSize:11, color:'var(--pg-ink-500)', marginTop:5, lineHeight:1.35,
                    display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical', overflow:'hidden'}}>
                    {descFor(e, lang)}
                  </div>
                  <div style={{display:'flex', alignItems:'baseline', justifyContent:'space-between', marginTop:8}}>
                    <span style={{fontFamily:'var(--pg-font-display)', fontSize:20, fontWeight:700, color:'var(--pg-blue-500)', letterSpacing:'-0.02em'}}>
                      ${e.price}{e.unit && <span style={{fontSize:11, fontWeight:500, color:'var(--pg-ink-500)'}}>{tr(e.unit, lang)}</span>}
                    </span>
                    <span style={{fontSize:10.5, color:'var(--pg-ink-500)'}}>{sellerFor(e)}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}

        {view === 'routes' && (
          <div style={{marginTop:14, display:'flex', flexDirection:'column', gap:12}}>
            <div className="pg-card" style={{
              padding:'12px 14px', display:'flex', alignItems:'center', gap:10,
              background:'var(--pg-aqua-100)', border:'0.5px solid var(--pg-aqua-400)',
            }}>
              {Icon.shield(16, 'var(--pg-aqua-700)')}
              <div style={{fontSize:12, color:'var(--pg-aqua-700)', fontWeight:500, lineHeight:1.4}}>
                {t.routesSaleOnly}
              </div>
            </div>
            {POOL_ROUTES.map(r => (
              <div key={r.id} className="pg-card pg-card-tap" style={{padding:14, display:'flex', gap:12}}>
                <div style={{width:90, height:90, borderRadius:12, overflow:'hidden', flexShrink:0}}>
                  <EquipImg category="Routes" height={90}/>
                </div>
                <div style={{flex:1, minWidth:0}}>
                  <div style={{fontSize:14, fontWeight:600, letterSpacing:'-0.01em', lineHeight:1.25}}>{tr(r.name, lang)}</div>
                  <div style={{display:'flex', gap:8, alignItems:'center', marginTop:4, flexWrap:'wrap'}}>
                    <span className="pg-chip pg-chip-aqua" style={{padding:'3px 8px', fontSize:11}}>{tr(r.revenue, lang)}</span>
                    <span style={{fontSize:11, color:'var(--pg-ink-500)'}}>{r.clients} {t.poolsWord} · {r.area}</span>
                  </div>
                  <div style={{display:'flex', alignItems:'baseline', justifyContent:'space-between', marginTop:9}}>
                    <div>
                      <div style={{fontSize:11, color:'var(--pg-ink-500)'}}>{t.asking}</div>
                      <div style={{fontFamily:'var(--pg-font-display)', fontSize:20, fontWeight:700, color:'var(--pg-blue-500)', letterSpacing:'-0.02em'}}>${r.est.toLocaleString()}</div>
                    </div>
                    <button className="pg-btn pg-btn-primary" style={{height:34, padding:'0 14px', fontSize:13}}>
                      {t.contact}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Sheet open={!!selected} onClose={()=>setSelected(null)} height="78%">
        {selected && (
          <div>
            <EquipImg category={selected.category} height={200}/>
            <div style={{padding:'14px 18px 80px'}}>
              <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:10}}>
                <h2 style={{margin:0, fontFamily:'var(--pg-font-display)', fontSize:20, fontWeight:700, letterSpacing:'-0.02em', lineHeight:1.2}}>{selected.name}</h2>
                <button onClick={()=>setSelected(null)} style={{
                  border:'none', background:'var(--pg-ink-100)', width:30, height:30,
                  borderRadius:'50%', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center',
                }}>{Icon.x(16, 'var(--pg-ink-700)')}</button>
              </div>
              <div style={{display:'flex', alignItems:'baseline', gap:6, marginTop:8}}>
                <span style={{fontFamily:'var(--pg-font-display)', fontSize:30, fontWeight:700, color:'var(--pg-blue-500)', letterSpacing:'-0.02em'}}>${selected.price}</span>
                {selected.unit && <span style={{fontSize:13, color:'var(--pg-ink-500)'}}>{tr(selected.unit, lang)}</span>}
                <span className="pg-chip" style={{marginLeft:8, padding:'2px 9px', fontSize:11, background:'var(--pg-blue-100)', color:'var(--pg-blue-700)', borderColor:'transparent'}}>{tr(selected.condition, lang).toLowerCase()}</span>
              </div>
              <div style={{display:'flex', alignItems:'center', gap:5, marginTop:8, fontSize:13, color:'var(--pg-ink-700)'}}>
                {Icon.pin(14, 'var(--pg-ink-700)')} {selected.loc} · {tr(catLabels[selected.category], lang)}
              </div>

              <div className="pg-divider" style={{margin:'18px 0'}}/>

              <div style={{display:'flex', alignItems:'center', gap:12}}>
                <Avatar name="Sandra Reyes" size={44}/>
                <div style={{flex:1, minWidth:0}}>
                  <div style={{fontSize:14, fontWeight:600}}>Sandra Reyes</div>
                  <div style={{display:'flex', alignItems:'center', gap:6, fontSize:12, color:'var(--pg-ink-500)'}}>
                    <Stars rating={4.8} size={11}/> 4.8 · 87 {lang==='pt'?'transações':lang==='es'?'transacciones':'transactions'}
                  </div>
                </div>
                <span className="pg-chip pg-chip-aqua" style={{fontSize:11}}>{t.verified}</span>
              </div>

              <div style={{marginTop:14, fontSize:14, lineHeight:1.5, color:'var(--pg-ink-700)'}}>
                {descFor(selected, lang)}
              </div>

              <div style={{display:'flex', gap:10, marginTop:18}}>
                <button onClick={openChat} className="pg-btn pg-btn-ghost" style={{flex:1}}>
                  {Icon.msg(16, 'var(--pg-blue-700)')} {t.message}
                </button>
                <button className="pg-btn pg-btn-primary" style={{flex:2}}>
                  {selected.mode === 'rent' ? t.requestRental : t.makeOffer}
                </button>
              </div>
            </div>
          </div>
        )}
      </Sheet>
    </div>
  );
}

// description helpers
function descFor(e, lang) {
  const map = {
    Pumps: { en:'Variable-speed pool pump, lightly used.', pt:'Bomba de velocidade variável, pouco uso.', es:'Bomba de velocidad variable, poco uso.' },
    Filters: { en:'High-rate sand filter, 24-inch tank.', pt:'Filtro de areia, tanque de 24 polegadas.', es:'Filtro de arena, tanque de 24 pulgadas.' },
    Vacuum: { en:'Automatic suction-side pool vacuum, barely used.', pt:'Aspirador automático para piscina, quase sem uso.', es:'Aspirador automático para piscina, casi sin uso.' },
    Heaters: { en:'Reliable propane pool heater, runs perfectly.', pt:'Aquecedor a gás confiável, funciona perfeitamente.', es:'Calentador a gas confiable, funciona perfectamente.' },
    Tools: { en:'Heavy-duty aluminum telescopic pole.', pt:'Haste telescópica de alumínio reforçada.', es:'Pértiga telescópica de aluminio reforzada.' },
  };
  return (map[e.category] || map.Tools)[lang] || (map[e.category] || map.Tools).en;
}
function sellerFor(e) {
  const sellers = ['PoolPro Mike','AquaServ','FilterKing','RentAPool','BluClear','DesertPools'];
  return sellers[e.id % sellers.length];
}

Object.assign(window, { MarketplaceScreen });
