// overlays.jsx — chat, notifications, paywall, post-menu

function ChatSheet({ open, onClose, lang='en' }) {
  const t = STRINGS[lang];
  const seed = lang==='pt' ? [
    { id:1, from:'them', text:'Oi! Vi seu anúncio da rota de terça — terça de manhã funciona pra mim.', time:'10:02' },
    { id:2, from:'me',   text:'Ótimo. 6 piscinas de água salgada, todos os produtos no local #1. R$225/piscina ok?', time:'10:04' },
    { id:3, from:'them', text:'Funciona. Posso ver o código do portão do condomínio?', time:'10:05' },
    { id:4, from:'me',   text:'Mando assim que aceitar — regra do sistema. Vamos fechar?', time:'10:05' },
  ] : lang==='es' ? [
    { id:1, from:'them', text:'¡Hola! Vi tu publicación de la ruta del martes — martes en la mañana me funciona.', time:'10:02 AM' },
    { id:2, from:'me',   text:'Genial. 6 piscinas de agua salada, todos los productos en el sitio #1. ¿$45/piscina?', time:'10:04 AM' },
    { id:3, from:'them', text:'Funciona. ¿Puedo ver el código del portón del condominio?', time:'10:05 AM' },
    { id:4, from:'me',   text:'Te lo envío cuando aceptes — regla del sistema. ¿Lo cerramos?', time:'10:05 AM' },
  ] : [
    { id:1, from:'them', text:'Hey! Saw your post for the Tuesday route — Tuesday morning works for me.', time:'10:02 AM' },
    { id:2, from:'me',   text:'Great. 6 saltwater pools, all chemicals at site #1. Cool with $45/pool?', time:'10:04 AM' },
    { id:3, from:'them', text:'Works. Can I see the gate code for the condo stop?', time:'10:05 AM' },
    { id:4, from:'me',   text:'Sending it once you accept — system rule. Wanna lock it in?', time:'10:05 AM' },
  ];
  const [messages, setMessages] = React.useState(seed);
  React.useEffect(()=>{ setMessages(seed); /* eslint-disable-next-line */ }, [lang]);

  const [draft, setDraft] = React.useState('');
  const scroller = React.useRef(null);

  React.useEffect(()=>{
    if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight;
  }, [messages.length, open]);

  const reply = lang==='pt' ? 'Beleza 👍' : lang==='es' ? 'Perfecto 👍' : 'Sounds good 👍';
  const now = t.justNow;

  const send = () => {
    if (!draft.trim()) return;
    setMessages(m => [...m, { id:Date.now(), from:'me', text:draft.trim(), time:now }]);
    setDraft('');
    setTimeout(()=> setMessages(m => [...m, { id:Date.now()+1, from:'them', text:reply, time:now }]), 1200);
  };

  return (
    <Sheet open={open} onClose={onClose} height="86%">
      <div style={{display:'flex', flexDirection:'column', height:'100%'}}>
        <div style={{display:'flex', alignItems:'center', gap:10, padding:'4px 14px 12px', borderBottom:'0.5px solid var(--pg-ink-200)'}}>
          <button onClick={onClose} style={{border:'none', background:'transparent', cursor:'pointer', padding:6, color:'var(--pg-blue-600)'}}>
            {Icon.chev(18, 'var(--pg-blue-600)', 'left')}
          </button>
          <Avatar name="Marcos Tavares" size={38}/>
          <div style={{flex:1, minWidth:0}}>
            <div style={{fontSize:14, fontWeight:600}}>Marcos Tavares</div>
            <div style={{fontSize:11, color:'var(--pg-aqua-700)', display:'flex', alignItems:'center', gap:4}}>
              <span style={{width:6, height:6, borderRadius:'50%', background:'var(--pg-aqua-500)'}}/> {t.activeNow}
            </div>
          </div>
          <IconButton>{Icon.more(16, 'var(--pg-ink-700)')}</IconButton>
        </div>

        <div style={{padding:'10px 14px', background:'var(--pg-blue-50)', display:'flex', alignItems:'center', gap:10, borderBottom:'0.5px solid var(--pg-ink-200)'}}>
          <div className="pg-img-aqua" style={{width:34, height:34, borderRadius:8, flexShrink:0}}>POOL</div>
          <div style={{flex:1, minWidth:0}}>
            <div style={{fontSize:12, fontWeight:600, color:'var(--pg-blue-700)'}}>
              {lang==='pt' ? 'Cobrir férias — 6 piscinas' : lang==='es' ? 'Cobertura vacaciones — 6 piscinas' : 'Vacation cover — 6 pools'}
            </div>
            <div style={{fontSize:11, color:'var(--pg-ink-500)'}}>
              Boca Raton · $45/{lang==='en'?'pool':'piscina'} · {t.tomorrow}
            </div>
          </div>
          <button className="pg-btn pg-btn-primary" style={{height:32, padding:'0 12px', fontSize:12}}>{t.viewJob}</button>
        </div>

        <div ref={scroller} style={{flex:1, overflow:'auto', padding:'14px', display:'flex', flexDirection:'column', gap:8}}>
          {messages.map(m => (
            <div key={m.id} style={{display:'flex', justifyContent: m.from==='me' ? 'flex-end' : 'flex-start'}}>
              <div style={{maxWidth:'78%'}}>
                <div style={{
                  padding:'9px 13px', borderRadius:16,
                  background: m.from==='me' ? 'var(--pg-blue-500)' : 'var(--pg-ink-100)',
                  color: m.from==='me' ? '#fff' : 'var(--pg-ink-900)',
                  fontSize:14, lineHeight:1.4,
                  borderBottomRightRadius: m.from==='me' ? 4 : 16,
                  borderBottomLeftRadius:  m.from==='me' ? 16 : 4,
                }}>{m.text}</div>
                <div style={{fontSize:10, color:'var(--pg-ink-500)', marginTop:3, textAlign: m.from==='me'?'right':'left', padding:'0 4px'}}>{m.time}</div>
              </div>
            </div>
          ))}
        </div>

        <div style={{padding:'10px 12px 14px', borderTop:'0.5px solid var(--pg-ink-200)', display:'flex', gap:8, alignItems:'flex-end'}}>
          <div style={{flex:1, background:'var(--pg-ink-100)', borderRadius:18, padding:'10px 14px', minHeight:42, display:'flex', alignItems:'center'}}>
            <input value={draft} onChange={e=>setDraft(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()}
                   placeholder={t.messagePh} style={{flex:1, border:'none', background:'transparent', outline:'none', fontSize:14, fontFamily:'inherit'}}/>
          </div>
          <button onClick={send} className="pg-press" style={{
            width:42, height:42, borderRadius:'50%', border:'none', cursor:'pointer',
            background: draft.trim() ? 'var(--pg-blue-500)' : 'var(--pg-ink-200)',
            color:'#fff', display:'flex', alignItems:'center', justifyContent:'center',
            transition:'background .15s ease',
          }}>{Icon.arrow(18, '#fff')}</button>
        </div>
      </div>
    </Sheet>
  );
}

function NotificationsSheet({ open, onClose, lang='en' }) {
  const t = STRINGS[lang];
  const whenMap = {
    justNow: t.justNow,
    min8: '8m',
    hours2: '2h',
    yesterday: t.yesterday,
  };
  return (
    <Sheet open={open} onClose={onClose} height="72%">
      <div style={{padding:'4px 18px 30px'}}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:14}}>
          <h2 style={{margin:0, fontSize:20, fontWeight:700, letterSpacing:'-0.02em'}}>{t.notifsTitle}</h2>
          <button style={{border:'none', background:'transparent', color:'var(--pg-blue-600)', fontSize:13, fontWeight:600, cursor:'pointer'}}>{t.markAllRead}</button>
        </div>

        <div style={{display:'flex', flexDirection:'column', gap:2}}>
          {NOTIFICATIONS.map(n => {
            const title = n.kind==='message' ? `${n.who} ${t[n.titleKey]}` : t[n.titleKey];
            const body = n.kind==='message' ? tr(n.quote, lang) :
                         n.kind==='apply'   ? `${n.who} ${t[n.bodyKey]}` :
                         n.kind==='rating'  ? `${n.who} ${t[n.bodyKey]}` :
                         t[n.bodyKey];
            return (
              <div key={n.id} style={{
                display:'flex', gap:12, padding:'12px 8px', borderRadius:10,
                background: n.unread ? 'var(--pg-blue-50)' : 'transparent',
                cursor:'pointer', position:'relative',
              }}>
                <div style={{
                  width:38, height:38, borderRadius:'50%', flexShrink:0,
                  background: n.kind==='job' ? 'var(--pg-aqua-500)' :
                              n.kind==='message' ? 'var(--pg-blue-500)' :
                              n.kind==='apply' ? 'var(--pg-aqua-700)' : 'oklch(0.78 0.15 80)',
                  display:'flex', alignItems:'center', justifyContent:'center', color:'#fff',
                }}>
                  {n.kind==='job'     && Icon.bolt(18, '#fff')}
                  {n.kind==='message' && Icon.msg(16, '#fff')}
                  {n.kind==='apply'   && Icon.check(16, '#fff')}
                  {n.kind==='rating'  && Icon.star(15, '#fff', true)}
                </div>
                <div style={{flex:1, minWidth:0}}>
                  <div style={{display:'flex', justifyContent:'space-between', gap:8}}>
                    <div style={{fontSize:13, fontWeight:600, letterSpacing:'-0.01em'}}>{title}</div>
                    <div style={{fontSize:11, color:'var(--pg-ink-500)', whiteSpace:'nowrap'}}>{whenMap[n.whenKey]}</div>
                  </div>
                  <div style={{fontSize:13, color:'var(--pg-ink-700)', marginTop:2, lineHeight:1.4}}>{body}</div>
                </div>
                {n.unread && <span style={{position:'absolute', top:18, right:8, width:8, height:8, borderRadius:'50%', background:'var(--pg-blue-500)'}}/>}
              </div>
            );
          })}
        </div>
      </div>
    </Sheet>
  );
}

function PaywallSheet({ open, onClose, setUser, lang='en' }) {
  const t = STRINGS[lang];
  const [tier, setTier] = React.useState('premium');
  const features = [
    { f:t.payF1, free:false, prem:true,  pro:true },
    { f:t.payF2, free:false, prem:true,  pro:true },
    { f:t.payF3, free:false, prem:false, pro:true },
    { f:t.payF4, free:false, prem:true,  pro:true },
    { f:t.payF5, free:false, prem:false, pro:true },
    { f:t.payF6, free:false, prem:false, pro:true },
  ];
  const month = lang==='pt'?'/mês':lang==='es'?'/mes':'/month';
  return (
    <Sheet open={open} onClose={onClose} height="88%">
      <div style={{padding:'0 18px 30px'}}>
        <div style={{padding:'4px 0 14px', display:'flex', justifyContent:'flex-end'}}>
          <button onClick={onClose} style={{border:'none', background:'var(--pg-ink-100)', width:30, height:30, borderRadius:'50%', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center'}}>
            {Icon.x(16, 'var(--pg-ink-700)')}
          </button>
        </div>

        <div style={{textAlign:'center'}}>
          <div style={{
            display:'inline-flex', alignItems:'center', justifyContent:'center',
            width:64, height:64, borderRadius:18, marginBottom:14,
            background:'linear-gradient(155deg, var(--pg-aqua-400), var(--pg-blue-500))',
          }}>
            {Icon.crown(28, '#fff')}
          </div>
          <h2 style={{margin:0, fontSize:26, fontWeight:700, letterSpacing:'-0.025em', lineHeight:1.1, whiteSpace:'pre-line'}}>
            {t.payTitle}
          </h2>
          <p style={{margin:'8px 16px 0', fontSize:14, color:'var(--pg-ink-500)', lineHeight:1.45}}>
            {t.paySub}
          </p>
        </div>

        <div className="pg-seg" style={{marginTop:18}}>
          <button className={`pg-seg-btn ${tier==='premium'?'on':''}`} onClick={()=>setTier('premium')}>{t.premium}</button>
          <button className={`pg-seg-btn ${tier==='pro'?'on':''}`}     onClick={()=>setTier('pro')}>{t.poolguyPro}</button>
        </div>

        <div className="pg-card" style={{padding:18, marginTop:14,
          background: tier==='pro' ? 'linear-gradient(135deg, var(--pg-blue-900), var(--pg-blue-700))' : 'var(--pg-white)',
          color: tier==='pro' ? '#fff' : 'inherit', border: tier==='pro' ? 'none' : '0.5px solid var(--pg-aqua-400)',
        }}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-end'}}>
            <div>
              <div style={{fontSize:12, fontWeight:700, letterSpacing:'0.06em', opacity:0.8}}>
                {tier==='pro' ? 'POOLGUY PRO' : t.premium.toUpperCase()}
              </div>
              <div style={{display:'flex', alignItems:'baseline', gap:4, marginTop:6}}>
                <span style={{fontSize:36, fontWeight:700, letterSpacing:'-0.03em'}}>
                  ${tier==='pro' ? '19.99' : '9.99'}
                </span>
                <span style={{fontSize:14, opacity:0.7}}>{month}</span>
              </div>
              <div style={{fontSize:12, opacity:0.7, marginTop:2}}>
                {tier==='pro' ? t.paySave : t.payTrial}
              </div>
            </div>
            {tier==='pro' && <span style={{
              fontSize:10, padding:'4px 8px', borderRadius:6, background:'var(--pg-aqua-500)',
              color:'var(--pg-blue-900)', fontWeight:700, letterSpacing:'0.05em',
            }}>{t.payBest}</span>}
          </div>
        </div>

        <div style={{marginTop:14}}>
          {features.map((f,i)=> {
            const has = tier==='pro' ? f.pro : f.prem;
            return (
              <div key={i} style={{display:'flex', alignItems:'center', gap:10, padding:'9px 0', borderBottom:'0.5px solid var(--pg-ink-200)'}}>
                <div style={{
                  width:22, height:22, borderRadius:'50%',
                  background: has ? 'var(--pg-aqua-100)' : 'var(--pg-ink-100)',
                  display:'flex', alignItems:'center', justifyContent:'center',
                }}>
                  {has ? Icon.check(13, 'var(--pg-aqua-700)') : Icon.x(11, 'var(--pg-ink-400)')}
                </div>
                <div style={{flex:1, fontSize:13, color: has ? 'var(--pg-ink-900)' : 'var(--pg-ink-500)'}}>{f.f}</div>
              </div>
            );
          })}
        </div>

        <button onClick={()=>{setUser(u=>({...u, tier})); onClose();}} className="pg-btn pg-btn-primary" style={{width:'100%', height:54, fontSize:16, marginTop:18}}>
          {t.startTrial} — ${tier==='pro' ? '19.99' : '9.99'}{month}
        </button>
        <div style={{fontSize:11, color:'var(--pg-ink-500)', textAlign:'center', marginTop:8, lineHeight:1.4}}>
          {t.cancelAnytime}<br/>
          {t.restore}
        </div>
      </div>
    </Sheet>
  );
}

function PostMenuSheet({ open, onClose, onPickQuickPool, lang='en' }) {
  const t = STRINGS[lang];
  const items = [
    { ic:Icon.bolt,      title:t.pmQuickPool,  sub:t.pmQuickPoolSub, kind:'aqua', onClick:onPickQuickPool },
    { ic:Icon.cart,      title:t.pmSellEq,     sub:t.pmSellEqSub, kind:'blue' },
    { ic:Icon.cart,      title:t.pmRentEq,     sub:t.pmRentEqSub, kind:'blue' },
    { ic:Icon.pin,       title:t.pmSellRoute,  sub:t.pmSellRouteSub, kind:'blue' },
    { ic:Icon.cal,       title:t.pmVacCover,   sub:t.pmVacCoverSub, kind:'blue' },
    { ic:Icon.briefcase, title:t.pmHireTech,   sub:t.pmHireTechSub,   kind:'blue' },
  ];
  return (
    <Sheet open={open} onClose={onClose} height="auto">
      <div style={{padding:'4px 18px 30px'}}>
        <h2 style={{margin:'4px 0 14px', fontSize:18, fontWeight:700, letterSpacing:'-0.01em', textAlign:'center'}}>
          {t.whatPost}
        </h2>
        <div style={{display:'flex', flexDirection:'column', gap:8}}>
          {items.map((it,i)=>(
            <button key={i} onClick={()=>{ onClose(); it.onClick && it.onClick(); }} className="pg-press" style={{
              display:'flex', alignItems:'center', gap:14, padding:'12px 14px', border:'none', cursor:'pointer',
              background:'var(--pg-white)', borderRadius:14, boxShadow:'var(--pg-shadow-1)', textAlign:'left',
            }}>
              <div style={{
                width:42, height:42, borderRadius:11,
                background: it.kind==='aqua' ? 'var(--pg-aqua-100)' : 'var(--pg-blue-100)',
                display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0,
              }}>{it.ic(20, it.kind==='aqua' ? 'var(--pg-aqua-700)' : 'var(--pg-blue-700)')}</div>
              <div style={{flex:1, minWidth:0}}>
                <div style={{fontSize:15, fontWeight:600, letterSpacing:'-0.01em'}}>{it.title}</div>
                <div style={{fontSize:12, color:'var(--pg-ink-500)', marginTop:1}}>{it.sub}</div>
              </div>
              {Icon.chev(16, 'var(--pg-ink-400)')}
            </button>
          ))}
        </div>
      </div>
    </Sheet>
  );
}

function Toast({ message, kind='success' }) {
  if (!message) return null;
  return (
    <div style={{
      position:'absolute', left:18, right:18, bottom:108, zIndex:200,
      padding:'12px 14px', borderRadius:14,
      background: kind==='success' ? 'var(--pg-aqua-700)' : 'var(--pg-ink-900)',
      color:'#fff', display:'flex', alignItems:'center', gap:10,
      boxShadow:'0 8px 24px rgba(0,0,0,0.2)',
      animation:'pg-sheet-up 0.28s cubic-bezier(.22,1,.36,1)',
    }}>
      {kind==='success' && Icon.check(18, '#fff')}
      <div style={{fontSize:13, fontWeight:500, lineHeight:1.4, flex:1}}>{message}</div>
    </div>
  );
}

Object.assign(window, { ChatSheet, NotificationsSheet, PaywallSheet, PostMenuSheet, Toast });
