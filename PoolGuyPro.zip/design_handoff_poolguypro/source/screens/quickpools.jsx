// quickpools.jsx — Google-Maps-style map with clickable pins + premium gate

function QuickPoolsScreen({ ctx }) {
  const { lang, user, openPaywall, openChat, openPost, openRegionEditor, regionsByDay, county } = ctx;
  const t = STRINGS[lang];
  const [selected, setSelected] = React.useState(null);
  const [highlighted, setHighlighted] = React.useState(null);
  const [applied, setApplied] = React.useState({});

  // Union of all selected cities across days (for the notif summary chip strip)
  const notifCities = React.useMemo(() => {
    const set = new Set();
    Object.values(regionsByDay || {}).forEach(arr => (arr||[]).forEach(c => set.add(c)));
    return [...set];
  }, [regionsByDay]);
  const activeDayCount = React.useMemo(
    () => Object.values(regionsByDay || {}).filter(arr => (arr||[]).length > 0).length,
    [regionsByDay]
  );

  const jobs = QUICK_POOLS;
  const cardRefs = React.useRef({});

  const scrollToJob = (id) => {
    setHighlighted(id);
    const el = cardRefs.current[id];
    if (el) el.scrollIntoView({behavior:'smooth', block:'center'});
    setTimeout(()=>setHighlighted(null), 1800);
  };

  return (
    <div className="pg-screen" style={{paddingBottom:110, background:'var(--pg-bg)'}}>
      {/* Navy header */}
      <NavyBar
        title={
          <div>
            <h1 style={{margin:0, fontFamily:'var(--pg-font-display)', fontSize:22, fontWeight:700, letterSpacing:'-0.02em'}}>{t.quickPools}</h1>
            <div style={{fontSize:11.5, opacity:0.75, marginTop:3}}>
              {lang==='pt'
                ? `Todos os trabalhos em ${county}`
                : lang==='es'
                  ? `Todos los trabajos en ${county}`
                  : `All jobs in ${county} County`}
            </div>
          </div>
        }
        right={
          <button onClick={openPost} className="pg-press" style={{
            width:38, height:38, borderRadius:'50%', border:'none', cursor:'pointer',
            background:'var(--pg-aqua-500)', color:'var(--pg-blue-900)',
            display:'flex', alignItems:'center', justifyContent:'center',
            boxShadow:'0 4px 10px oklch(0.72 0.14 178 / 0.45)',
          }} aria-label="New Quick Pool">{Icon.plus(20, 'var(--pg-blue-900)')}</button>
        }
      >
        {/* Notification regions indicator */}
        <div style={{
          marginTop:12, display:'flex', alignItems:'center', justifyContent:'space-between',
          background:'rgba(255,255,255,0.10)', borderRadius:12, padding:'10px 14px',
          backdropFilter:'blur(8px)', gap:10,
        }}>
          <div style={{minWidth:0, flex:1}}>
            <div style={{fontSize:10, opacity:0.7, letterSpacing:'0.06em', fontWeight:700, display:'flex', alignItems:'center', gap:5}}>
              {Icon.bell(11, 'rgba(255,255,255,0.85)')}
              {lang==='pt' ? 'NOTIFIC. POR DIA' : lang==='es' ? 'NOTIF. POR DÍA' : 'NOTIF. BY DAY'}
            </div>
            <div style={{fontSize:12.5, fontWeight:600, marginTop:3, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>
              {notifCities.length > 0
                ? notifCities.slice(0,3).join(' · ') + (notifCities.length > 3 ? ` +${notifCities.length-3}` : '')
                : (lang==='pt'?'Nenhuma cidade configurada':lang==='es'?'Sin ciudades configuradas':'No cities set')}
            </div>
            <div style={{fontSize:10, opacity:0.6, marginTop:2}}>
              {activeDayCount}/7 {lang==='pt'?'dias ativos':lang==='es'?'días activos':'days active'}
            </div>
          </div>
          <button onClick={openRegionEditor} style={{
            border:'none', background:'rgba(255,255,255,0.16)', color:'#fff',
            height:30, padding:'0 12px', borderRadius:8, fontSize:12, fontWeight:600, cursor:'pointer',
            display:'inline-flex', alignItems:'center', gap:5, flexShrink:0,
          }}>{Icon.cal(13, '#fff')} {t.edit}</button>
        </div>
      </NavyBar>

      {/* Google-Maps-style map */}
      <div style={{padding:'14px 18px 0'}}>
        <GoogleMapsBlock jobs={jobs} selectedId={selected?.id} onPinClick={(j)=>{ setSelected(j); }}
          highlighted={highlighted} onPinHover={(j)=>scrollToJob(j.id)} />
      </div>

      {/* Job list */}
      <div style={{padding:'14px 18px 0', display:'flex', flexDirection:'column', gap:10}}>
        <div style={{
          padding:'10px 12px', borderRadius:11, background:'var(--pg-blue-50)',
          border:'0.5px solid var(--pg-blue-100)',
          display:'flex', alignItems:'flex-start', gap:9,
        }}>
          <div style={{flexShrink:0, marginTop:1}}>{Icon.bell(14, 'var(--pg-blue-700)')}</div>
          <div style={{fontSize:11.5, color:'var(--pg-blue-700)', lineHeight:1.4}}>
            {lang==='pt'
              ? <>Mostrando <b>todos os trabalhos do condado de {county}</b>. Você só será <b>notificado</b> dos trabalhos nas cidades e dias configurados.</>
              : lang==='es'
                ? <>Mostrando <b>todos los trabajos del condado de {county}</b>. Solo recibirás <b>notificaciones</b> de trabajos en las ciudades y días configurados.</>
                : <>Showing <b>all jobs in {county} County</b>. You're only <b>notified</b> for jobs in your configured cities and days.</>}
          </div>
        </div>

        <div style={{
          fontFamily:'var(--pg-font-display)', fontSize:14, fontWeight:700,
          color:'var(--pg-ink-700)', letterSpacing:'-0.01em',
          display:'flex', alignItems:'center', justifyContent:'space-between',
        }}>
          <span>{lang==='pt'?`${jobs.length} trabalhos disponíveis`:lang==='es'?`${jobs.length} trabajos disponibles`:`${jobs.length} jobs available`}</span>
          {user.tier === 'free' && (
            <span style={{fontSize:11, color:'var(--pg-aqua-700)', display:'inline-flex', alignItems:'center', gap:4, fontWeight:600}}>
              {Icon.lock(11, 'var(--pg-aqua-700)')} {lang==='pt'?'Premium aplica':lang==='es'?'Premium postula':'Premium applies'}
            </span>
          )}
        </div>

        {jobs.map(j => {
          const isApplied = !!applied[j.id];
          const isHighlighted = highlighted === j.id;
          return (
            <article key={j.id}
              ref={el => { cardRefs.current[j.id] = el; }}
              className="pg-card pg-card-tap" onClick={()=>setSelected(j)}
              style={{
                padding:14,
                transition: 'box-shadow .25s ease, transform .25s ease',
                boxShadow: isHighlighted ? '0 0 0 2px var(--pg-aqua-500), 0 8px 20px oklch(0.72 0.14 178 / 0.25)' : 'var(--pg-shadow-1)',
              }}>
              <div style={{display:'flex', justifyContent:'space-between', gap:10, alignItems:'flex-start'}}>
                <div style={{flex:1, minWidth:0}}>
                  <div style={{display:'flex', alignItems:'center', gap:6, marginBottom:6, flexWrap:'wrap'}}>
                    {isApplied && <span className="pg-badge pg-badge-applied">✓ {t.applied}</span>}
                    <span style={{fontSize:11, color:'var(--pg-ink-500)', display:'inline-flex', alignItems:'center', gap:4}}>
                      {Icon.clock(11, 'var(--pg-ink-500)')} {tr(j.when, lang)}
                    </span>
                  </div>
                  <h3 style={{margin:0, fontFamily:'var(--pg-font-display)', fontSize:16, fontWeight:700, letterSpacing:'-0.015em', lineHeight:1.25}}>{tr(j.title, lang)}</h3>
                  <div style={{display:'flex', alignItems:'center', gap:6, marginTop:5, fontSize:12, color:'var(--pg-ink-500)'}}>
                    {Icon.pin(12, 'var(--pg-ink-500)')} {j.loc} · {tr(j.dist, lang)}
                  </div>
                </div>
                <div style={{textAlign:'right'}}>
                  <div style={{fontSize:11, color:'var(--pg-ink-500)'}}>{j.pools} {j.pools>1?t.poolsWord:(lang==='pt'?'piscina':lang==='es'?'piscina':'pool')}</div>
                  {j.price === 'neg' ? (
                    <div style={{fontSize:14, fontWeight:700, color:'var(--pg-ink-700)', marginTop:2}}>{t.negotiable}</div>
                  ) : (
                    <>
                      <div style={{fontFamily:'var(--pg-font-display)', fontSize:20, fontWeight:700, color:'var(--pg-blue-500)', letterSpacing:'-0.02em', marginTop:2}}>${j.price}</div>
                      <div style={{fontSize:10, color:'var(--pg-ink-500)'}}>{t.perPool}</div>
                    </>
                  )}
                </div>
              </div>

              <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginTop:12}}>
                <div style={{display:'flex', alignItems:'center', gap:8, minWidth:0}}>
                  <Avatar name={j.poster} size={26}/>
                  <div style={{minWidth:0}}>
                    <div style={{fontSize:12, fontWeight:600, color:'var(--pg-ink-700)'}}>{j.poster}</div>
                    <div style={{display:'flex', alignItems:'center', gap:3, fontSize:11, color:'var(--pg-ink-500)'}}>
                      <Stars rating={j.rating} size={9}/> {j.rating}
                    </div>
                  </div>
                </div>
                {user.tier === 'free' ? (
                  <button onClick={(e)=>{e.stopPropagation(); openPaywall();}} className="pg-btn pg-btn-outline" style={{height:34, padding:'0 12px', fontSize:12, borderRadius:999}}>
                    {Icon.lock(12, 'var(--pg-ink-700)')} {t.unlock}
                  </button>
                ) : isApplied ? (
                  <button className="pg-btn pg-btn-ghost" style={{height:34, padding:'0 14px', fontSize:13, borderRadius:999}}>
                    {Icon.check(14, 'var(--pg-blue-700)')} {t.applied}
                  </button>
                ) : (
                  <button onClick={(e)=>{e.stopPropagation(); setApplied({...applied,[j.id]:true});}}
                          className="pg-btn pg-btn-primary" style={{height:34, padding:'0 14px', fontSize:13, borderRadius:999}}>
                    {t.apply}
                  </button>
                )}
              </div>
            </article>
          );
        })}
      </div>

      <Sheet open={!!selected} onClose={()=>setSelected(null)} height="86%">
        {selected && (
          <QuickPoolDetails job={selected} user={user} t={t} lang={lang}
            applied={!!applied[selected.id]}
            onApply={()=>setApplied({...applied,[selected.id]:true})}
            onUnlock={openPaywall}
            onChat={openChat}
            onClose={()=>setSelected(null)}
          />
        )}
      </Sheet>
    </div>
  );
}

// ── Google-Maps-style map ─────────────────────────────────────
function GoogleMapsBlock({ jobs, selectedId, onPinClick, highlighted, onPinHover }) {
  // Fixed positions per job — feels like a real map
  const pins = [
    { id:1, x:'24%', y:'34%' },
    { id:2, x:'62%', y:'28%' },
    { id:3, x:'73%', y:'68%' },
    { id:4, x:'38%', y:'72%' },
    { id:5, x:'52%', y:'48%' },
  ];

  return (
    <div className="pg-card" style={{
      position:'relative', height:200, overflow:'hidden', padding:0,
      border:'0.5px solid var(--pg-ink-200)',
    }}>
      {/* Map base — Google-Maps light palette */}
      <div style={{
        position:'absolute', inset:0,
        background:'#e8edf2', /* google land color */
      }}/>

      {/* Roads + features */}
      <svg viewBox="0 0 400 200" preserveAspectRatio="none" style={{position:'absolute', inset:0, width:'100%', height:'100%'}}>
        {/* Parks */}
        <path d="M0 130 Q60 100 110 130 L 130 200 L 0 200 Z" fill="#c8e6c9"/>
        <ellipse cx="340" cy="20" rx="80" ry="40" fill="#c8e6c9"/>
        {/* Water */}
        <path d="M0 0 Q40 30 80 12 T 160 22 L 160 0 Z" fill="#c8e1f2"/>
        <ellipse cx="380" cy="180" rx="60" ry="50" fill="#c8e1f2"/>
        {/* Major roads — yellow/orange (like Google highways) */}
        <path d="M0 90 L400 110" stroke="#fff" strokeWidth="6"/>
        <path d="M0 90 L400 110" stroke="#fcd97a" strokeWidth="3.5"/>
        <path d="M200 0 L180 200" stroke="#fff" strokeWidth="6"/>
        <path d="M200 0 L180 200" stroke="#fcd97a" strokeWidth="3.5"/>
        {/* Minor roads — white */}
        <path d="M0 50 L400 60"  stroke="#ffffff" strokeWidth="3"/>
        <path d="M0 160 L400 165" stroke="#ffffff" strokeWidth="3"/>
        <path d="M80 0 L70 200"   stroke="#ffffff" strokeWidth="3"/>
        <path d="M290 0 L310 200" stroke="#ffffff" strokeWidth="3"/>
        <path d="M120 30 L320 80" stroke="#ffffff" strokeWidth="2"/>
        <path d="M40 130 L380 145" stroke="#ffffff" strokeWidth="2"/>
        {/* Road outlines (thin gray) */}
        <path d="M0 50 L400 60"  stroke="#dadce0" strokeWidth="0.5" fill="none"/>
        <path d="M0 160 L400 165" stroke="#dadce0" strokeWidth="0.5" fill="none"/>
        <path d="M80 0 L70 200"   stroke="#dadce0" strokeWidth="0.5" fill="none"/>
        <path d="M290 0 L310 200" stroke="#dadce0" strokeWidth="0.5" fill="none"/>
        {/* Labels (Google style) */}
        <text x="50" y="180" fontSize="8" fill="#5f6368" fontFamily="Inter, sans-serif" fontWeight="500">Heritage Park</text>
        <text x="320" y="35" fontSize="8" fill="#5f6368" fontFamily="Inter, sans-serif" fontWeight="500">City Park</text>
        <text x="350" y="195" fontSize="8" fill="#1a73e8" fontFamily="Inter, sans-serif" fontWeight="500">Lake</text>
        <text x="100" y="105" fontSize="7" fill="#5f6368" fontFamily="Inter, sans-serif">FL-869</text>
        <text x="195" y="100" fontSize="7" fill="#5f6368" fontFamily="Inter, sans-serif" transform="rotate(85 200 100)">I-95</text>
      </svg>

      {/* Job pins */}
      {pins.map(pin => {
        const job = jobs.find(j => j.id === pin.id);
        if (!job) return null;
        const isSel = selectedId === pin.id;
        const isHl  = highlighted === pin.id;
        return (
          <button key={pin.id} onClick={(e)=>{e.stopPropagation(); onPinClick(job);}}
            onMouseEnter={()=>onPinHover && onPinHover(job)}
            style={{
              position:'absolute', left:pin.x, top:pin.y, transform:'translate(-50%, -100%)',
              border:'none', background:'transparent', cursor:'pointer', padding:0,
              zIndex: isSel || isHl ? 5 : 2,
            }}>
            <div style={{position:'relative', filter: isSel || isHl ? 'drop-shadow(0 2px 6px rgba(0,0,0,0.3))' : 'drop-shadow(0 1px 2px rgba(0,0,0,0.2))'}}>
              <svg width={isSel||isHl?34:28} height={isSel||isHl?44:36} viewBox="0 0 28 36" style={{transition:'all .2s ease'}}>
                <path d="M14 0 C6 0 0 6 0 14 C0 22 14 36 14 36 C14 36 28 22 28 14 C28 6 22 0 14 0 Z"
                      fill={job.price === 'neg' ? '#fbbc04' : 'var(--pg-blue-500)'}
                      stroke="#fff" strokeWidth="1.5"/>
                <circle cx="14" cy="13" r="6.5" fill="#fff"/>
                <text x="14" y="16.5" textAnchor="middle" fontSize="8" fontWeight="700" fill="var(--pg-blue-700)" fontFamily="Inter, sans-serif">
                  {job.price === 'neg' ? '?' : `$${job.price}`}
                </text>
              </svg>
            </div>
          </button>
        );
      })}

      {/* You-are-here */}
      <div style={{position:'absolute', left:'48%', top:'52%', transform:'translate(-50%,-50%)', zIndex:3}}>
        <div style={{
          width:14, height:14, borderRadius:'50%', background:'#1a73e8',
          border:'2.5px solid #fff', boxShadow:'0 0 0 6px rgba(26,115,232,0.18)',
        }}/>
      </div>

      {/* Controls (Google Maps style) */}
      <div style={{position:'absolute', right:8, top:8, display:'flex', flexDirection:'column', gap:4}}>
        <button style={mapBtnStyle}>{Icon.plus(13, '#3c4043')}</button>
        <button style={mapBtnStyle}>
          <svg width="13" height="2" viewBox="0 0 13 2"><rect width="13" height="2" rx="1" fill="#3c4043"/></svg>
        </button>
      </div>
      <div style={{position:'absolute', right:8, bottom:8}}>
        <button style={mapBtnStyle} aria-label="Center">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#1a73e8" strokeWidth="2" strokeLinecap="round">
            <circle cx="12" cy="12" r="3" fill="#1a73e8"/>
            <path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>
          </svg>
        </button>
      </div>

      {/* Top-left Google-Maps style search hint */}
      <div style={{
        position:'absolute', left:8, top:8, background:'#fff',
        borderRadius:6, padding:'5px 9px', fontSize:11, color:'#3c4043',
        boxShadow:'0 1px 2px rgba(60,64,67,0.3), 0 1px 3px rgba(60,64,67,0.15)',
        display:'inline-flex', alignItems:'center', gap:6, fontWeight:500,
      }}>
        {Icon.search(12, '#3c4043')} South Florida
      </div>
    </div>
  );
}

const mapBtnStyle = {
  width:28, height:28, borderRadius:4,
  background:'#fff', border:'none', cursor:'pointer',
  display:'flex', alignItems:'center', justifyContent:'center',
  boxShadow:'0 1px 2px rgba(60,64,67,0.3), 0 1px 3px rgba(60,64,67,0.15)',
};

// ── Detail view ──────────────────────────────────────────────
function QuickPoolDetails({ job, user, t, lang, applied, onApply, onUnlock, onChat, onClose }) {
  const locked = user.tier === 'free';

  return (
    <div style={{padding:'8px 0 100px'}}>
      <div style={{padding:'4px 18px 0', display:'flex', justifyContent:'flex-end'}}>
        <button onClick={onClose} style={{border:'none', background:'var(--pg-ink-100)', width:30, height:30, borderRadius:'50%', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center'}}>
          {Icon.x(16, 'var(--pg-ink-700)')}
        </button>
      </div>

      <div style={{padding:'4px 18px 0'}}>
        <h2 style={{margin:0, fontFamily:'var(--pg-font-display)', fontSize:22, fontWeight:700, letterSpacing:'-0.02em', lineHeight:1.2}}>{tr(job.title, lang)}</h2>
        <div style={{display:'flex', alignItems:'center', gap:6, marginTop:8, fontSize:13, color:'var(--pg-ink-700)'}}>
          {Icon.pin(14)} {job.loc} · {tr(job.dist, lang)}
        </div>

        <div style={{
          marginTop:14, padding:'14px 16px', borderRadius:14,
          background:'var(--pg-blue-50)', border:'0.5px solid var(--pg-blue-100)',
          display:'flex', justifyContent:'space-between', alignItems:'center',
        }}>
          <div>
            <div style={{fontSize:11, color:'var(--pg-ink-500)', letterSpacing:'0.05em', fontWeight:600}}>{t.offer}</div>
            {job.price === 'neg' ? (
              <div style={{fontSize:22, fontWeight:700, marginTop:2, fontFamily:'var(--pg-font-display)'}}>{t.negotiable}</div>
            ) : (
              <div style={{fontFamily:'var(--pg-font-display)', fontSize:26, fontWeight:700, color:'var(--pg-blue-500)', letterSpacing:'-0.02em', marginTop:2}}>
                ${job.price} <span style={{fontSize:13, color:'var(--pg-ink-500)', fontWeight:500}}>· {t.perPool}</span>
              </div>
            )}
          </div>
          <div style={{textAlign:'right'}}>
            <div style={{fontSize:11, color:'var(--pg-ink-500)', letterSpacing:'0.05em', fontWeight:600}}>{t.pools}</div>
            <div style={{fontFamily:'var(--pg-font-display)', fontSize:26, fontWeight:700, letterSpacing:'-0.02em', marginTop:2}}>{job.pools}</div>
          </div>
          <div style={{textAlign:'right'}}>
            <div style={{fontSize:11, color:'var(--pg-ink-500)', letterSpacing:'0.05em', fontWeight:600}}>{t.whenLabel}</div>
            <div style={{fontSize:13, fontWeight:600, marginTop:2, maxWidth:90}}>{tr(job.when, lang)}</div>
          </div>
        </div>

        {/* Condo extras (only if condo) */}
        {job.type === 'condo' && (
          <div className="pg-card" style={{padding:'12px 14px', marginTop:14, background:'#fff'}}>
            <div style={{fontSize:11, color:'var(--pg-ink-500)', fontWeight:600, letterSpacing:'0.05em', marginBottom:8}}>{t.accessDetails}</div>
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10}}>
              <DetailPill icon={Icon.key(14, 'var(--pg-blue-700)')} label={t.gateCode} value={locked ? '••••' : '8472*'}/>
              <DetailPill icon={Icon.user(14, 'var(--pg-blue-700)')} label={t.doorman} value={job.doorman ? t.yes : t.no}/>
              <DetailPill icon={Icon.dog(14, 'var(--pg-blue-700)')} label={t.dogLbl} value={job.dog ? t.yes : t.no}/>
              <DetailPill icon={Icon.pool(14, 'var(--pg-blue-700)')} label={t.saltwater} value={t.yes}/>
            </div>
          </div>
        )}

        <div style={{marginTop:14}}>
          <div style={{fontSize:11, color:'var(--pg-ink-500)', fontWeight:600, letterSpacing:'0.05em', marginBottom:6}}>{t.description}</div>
          <p style={{margin:0, fontSize:14, lineHeight:1.5, color:'var(--pg-ink-700)'}}>{tr(job.body, lang)}</p>
        </div>

        <div className="pg-card" style={{padding:14, marginTop:14, display:'flex', alignItems:'center', gap:12}}>
          <Avatar name={job.poster} size={48}/>
          <div style={{flex:1, minWidth:0}}>
            <div style={{fontSize:15, fontWeight:600}}>{job.poster}</div>
            <div style={{display:'flex', alignItems:'center', gap:6, fontSize:12, color:'var(--pg-ink-500)', marginTop:2}}>
              <Stars rating={job.rating} size={11}/> {job.rating} · 26 {t.completedJobs}
            </div>
          </div>
          <span className="pg-chip pg-chip-aqua" style={{fontSize:11}}>{Icon.shield(11, 'var(--pg-aqua-700)')} {t.verified}</span>
        </div>

        {locked && (
          <div style={{
            marginTop:14, padding:16, borderRadius:14, color:'#fff',
            background:'linear-gradient(135deg, var(--pg-blue-700), oklch(0.45 0.15 230))',
            display:'flex', gap:12, alignItems:'flex-start',
          }}>
            {Icon.crown(22, 'oklch(0.85 0.15 90)')}
            <div style={{flex:1}}>
              <div style={{fontFamily:'var(--pg-font-display)', fontSize:14, fontWeight:700}}>{t.premiumUnlocks}</div>
              <div style={{fontSize:12, opacity:0.85, marginTop:3, lineHeight:1.4}}>
                {t.premiumUnlocksDesc}
              </div>
              <button onClick={onUnlock} className="pg-btn pg-btn-aqua" style={{height:36, padding:'0 14px', fontSize:13, marginTop:10, borderRadius:999}}>
                {t.unlockPrice}
              </button>
            </div>
          </div>
        )}
      </div>

      <div style={{
        position:'sticky', bottom:0, padding:'12px 18px',
        background:'linear-gradient(180deg, transparent, var(--pg-white) 25%)',
        display:'flex', gap:10, marginTop:14,
      }}>
        <button onClick={onChat} disabled={locked} className="pg-btn pg-btn-ghost" style={{flex:1, opacity:locked?0.5:1, borderRadius:999}}>
          {Icon.msg(16, 'var(--pg-blue-700)')} {t.contact}
        </button>
        <button onClick={locked ? onUnlock : onApply} className={`pg-btn ${applied?'pg-btn-ghost':'pg-btn-primary'}`} style={{flex:2, borderRadius:999}}>
          {locked ? <>{Icon.lock(14, '#fff')} {t.unlockApply}</> :
           applied ? <>{Icon.check(15, 'var(--pg-blue-700)')} {t.applied}</> :
           <>{t.apply} — {t.fastTrack}</>}
        </button>
      </div>
    </div>
  );
}

function DetailPill({ icon, label, value }) {
  return (
    <div style={{display:'flex', alignItems:'center', gap:8, padding:'8px 10px', borderRadius:10, background:'var(--pg-blue-50)'}}>
      {icon}
      <div style={{minWidth:0}}>
        <div style={{fontSize:10, color:'var(--pg-ink-500)', textTransform:'uppercase', letterSpacing:'0.04em'}}>{label}</div>
        <div style={{fontSize:13, fontWeight:600, marginTop:1}}>{value}</div>
      </div>
    </div>
  );
}

Object.assign(window, { QuickPoolsScreen });
