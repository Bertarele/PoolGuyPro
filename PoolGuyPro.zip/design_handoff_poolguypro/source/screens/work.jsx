// work.jsx — Hiring / Technicians (matching layout) / Vacation with month+weekday+region

function WorkScreen({ ctx }) {
  const { lang, openChat, goTab, openPostMenu } = ctx;
  const t = STRINGS[lang];
  const [sub, setSub] = React.useState('hiring');
  const [vacTab, setVacTab] = React.useState('posted');
  const [vacSheetOpen, setVacSheetOpen] = React.useState(false);

  const subIcons = {
    hiring: (s, c) => Icon.briefcase(s, c),
    techs:  (s, c) => (
      <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="8" r="5"/>
        <path d="M8.21 13.89 7 22l5-3 5 3-1.21-8.12"/>
      </svg>
    ),
    vac: (s, c) => (
      <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 22V8"/>
        <path d="M12 8c-2-2-5-2-7 0 2 2 5 2 7 0Z"/>
        <path d="M12 8c2-2 5-2 7 0-2 2-5 2-7 0Z"/>
        <path d="M5 12c2 0 4 1 4 3M19 12c-2 0-4 1-4 3"/>
      </svg>
    ),
  };

  return (
    <div className="pg-screen" style={{paddingBottom:110}}>
      <NavyBar
        title={t.work}
        leftBack onBack={()=>goTab('home')}
        right={
          <button onClick={sub==='vac' ? ()=>setVacSheetOpen(true) : openPostMenu} className="pg-press" style={{
            width:38, height:38, borderRadius:'50%', border:'none', cursor:'pointer',
            background:'rgba(255,255,255,0.14)', border:'0.5px solid rgba(255,255,255,0.18)',
            color:'#fff', display:'flex', alignItems:'center', justifyContent:'center',
          }} aria-label="New posting">{Icon.plus(20, '#fff')}</button>
        }
      />

      <div style={{padding:'0 18px'}}>
        <div className="pg-card" style={{padding:6, marginTop:-6, display:'flex', gap:0}}>
          {[
            { id:'hiring', label:t.hiring },
            { id:'techs',  label:t.technicians },
            { id:'vac',    label:t.vacation },
          ].map(s => {
            const on = sub === s.id;
            return (
              <button key={s.id} onClick={()=>setSub(s.id)} style={{
                flex:1, padding:'10px 6px', border:'none', borderRadius:10, cursor:'pointer',
                background: on ? 'var(--pg-blue-500)' : 'transparent',
                color: on ? '#fff' : 'var(--pg-ink-700)',
                fontWeight:600, fontSize:13.5, letterSpacing:'-0.005em',
                display:'inline-flex', alignItems:'center', justifyContent:'center', gap:6,
                fontFamily:'inherit', transition:'all .15s ease',
                boxShadow: on ? '0 4px 10px oklch(0.58 0.16 235 / 0.30)' : 'none',
              }}>
                {subIcons[s.id](15, on ? '#fff' : 'var(--pg-ink-500)')}
                {s.label}
              </button>
            );
          })}
        </div>
      </div>

      <div style={{padding:'14px 18px 0'}}>
        {sub === 'hiring' && <HiringPanel t={t} lang={lang} onChat={openChat}/>}
        {sub === 'techs'  && <TechsPanel  t={t} lang={lang} onChat={openChat}/>}
        {sub === 'vac'    && <VacationPanel t={t} lang={lang} vacTab={vacTab} setVacTab={setVacTab}
                              onChat={openChat} onCreate={()=>setVacSheetOpen(true)}/>}
      </div>

      <Sheet open={vacSheetOpen} onClose={()=>setVacSheetOpen(false)} height="92%">
        <PostVacationSheet onClose={()=>setVacSheetOpen(false)} lang={lang} onSubmit={()=>setVacSheetOpen(false)}/>
      </Sheet>
    </div>
  );
}

// ── Card with company-style header ────────────────────────────
function HiringPanel({ t, lang, onChat }) {
  const Company = (s=20, c='var(--pg-blue-500)') => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="4" y="3" width="16" height="18" rx="2"/>
      <path d="M9 8h2M13 8h2M9 12h2M13 12h2M9 16h2M13 16h2"/>
    </svg>
  );
  const Briefcase = (s=13, c='var(--pg-ink-500)') => Icon.briefcase(s, c);
  const License = (s=13, c='var(--pg-ink-500)') => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="6" width="18" height="13" rx="2"/><path d="M7 11h4M7 14h6M14 10h4v6h-4z"/>
    </svg>
  );
  const cdlLbl = lang==='pt'?'Carteira de motorista obrigatória':lang==='es'?'Licencia de conducir requerida':'Driver license required';
  const eqProv = lang==='pt'?'Equipamento fornecido':lang==='es'?'Equipo provisto':'Equipment provided';

  return (
    <div style={{display:'flex', flexDirection:'column', gap:12}}>
      {HIRING.map(h => (
        <article key={h.id} className="pg-card" style={{padding:'14px 16px 14px'}}>
          <div style={{display:'flex', alignItems:'center', gap:10, marginBottom:8}}>
            <div style={{
              width:28, height:28, borderRadius:7, background:'var(--pg-blue-100)',
              display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0,
            }}>{Company(15, 'var(--pg-blue-700)')}</div>
            <h3 style={{margin:0, fontFamily:'var(--pg-font-display)', fontSize:16, fontWeight:700, letterSpacing:'-0.015em'}}>{h.company}</h3>
          </div>
          <p style={{margin:0, fontSize:13, lineHeight:1.45, color:'var(--pg-ink-700)'}}>
            {descForHiring(h, lang)}
          </p>
          <div style={{display:'flex', flexDirection:'column', gap:6, marginTop:10, fontSize:12.5, color:'var(--pg-ink-500)'}}>
            <div style={{display:'flex', alignItems:'center', gap:12, flexWrap:'wrap'}}>
              <span style={{display:'inline-flex', alignItems:'center', gap:5}}>
                {Icon.pin(13, 'var(--pg-ink-500)')} {h.loc}
              </span>
              <span style={{display:'inline-flex', alignItems:'center', gap:5}}>
                {Briefcase(13, 'var(--pg-ink-500)')} {eqProv}
              </span>
            </div>
            <div style={{display:'inline-flex', alignItems:'center', gap:5}}>
              {License(13, 'var(--pg-ink-500)')} {cdlLbl}
            </div>
          </div>
          <div className="pg-divider" style={{margin:'12px 0'}}/>
          <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
            <div style={{
              fontFamily:'var(--pg-font-display)', fontSize:16, fontWeight:700,
              color: tr(h.pay, lang) === t.negotiable ? 'var(--pg-aqua-700)' : 'var(--pg-blue-500)',
              letterSpacing:'-0.01em',
            }}>{tr(h.pay, lang)}</div>
            <button className="pg-btn pg-btn-primary" style={{height:36, padding:'0 18px', fontSize:13, borderRadius:999}}>{t.apply}</button>
          </div>
        </article>
      ))}
    </div>
  );
}

function descForHiring(h, lang) {
  const descs = {
    1: { en:'Looking for a reliable pool tech for our growing route. Full training provided.',
         pt:'Procurando técnico de piscina confiável para nossa rota em crescimento. Treinamento completo.',
         es:'Buscamos técnico de piscina confiable para nuestra ruta en crecimiento. Capacitación completa.' },
    2: { en:'Expanding company needs experienced technician. Truck and equipment provided. CPO preferred.',
         pt:'Empresa em expansão precisa de técnico experiente. Veículo e equipamentos fornecidos. CPO preferencial.',
         es:'Empresa en expansión necesita técnico con experiencia. Camioneta y equipo provistos. CPO preferido.' },
    3: { en:'High-end residential route. Must have own equipment and truck. Premium clientele.',
         pt:'Rota residencial premium. Necessário equipamento e veículo próprios. Clientela exclusiva.',
         es:'Ruta residencial premium. Necesario equipo y camioneta propios. Clientela exclusiva.' },
  };
  return (descs[h.id] || descs[1])[lang] || (descs[h.id] || descs[1]).en;
}

// ── Technicians — same card layout as Hiring ─────────────────
function TechsPanel({ t, lang, onChat }) {
  const Briefcase = (s=13, c='var(--pg-ink-500)') => Icon.briefcase(s, c);
  const Tool = (s=13, c='var(--pg-ink-500)') => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M14 7a4 4 0 1 0-5 5l-6 6 3 3 6-6a4 4 0 0 0 5-5l-3 3-3-3z"/>
    </svg>
  );
  const verifiedLbl = lang==='pt'?'Técnico verificado':lang==='es'?'Técnico verificado':'Verified technician';
  const ownEquipLbl = lang==='pt'?'Equipamento próprio':lang==='es'?'Equipo propio':'Own equipment';

  const descForTech = (tech, lang) => {
    const map = {
      1: { en:'Specialized in pump and motor repair. 12 years of field experience. Same-day service available.',
           pt:'Especializado em reparo de bombas e motores. 12 anos de experiência. Atendimento no mesmo dia.',
           es:'Especializado en reparación de bombas y motores. 12 años de experiencia. Servicio mismo día.' },
      2: { en:'Heater and heat-pump diagnostics. Pentair and Hayward certified.',
           pt:'Diagnóstico de aquecedores e bombas de calor. Certificado Pentair e Hayward.',
           es:'Diagnóstico de calentadores y bombas de calor. Certificado Pentair y Hayward.' },
      3: { en:'Automation, salt-cell replacement and full equipment installs. Works weekends.',
           pt:'Automação, troca de células de sal e instalações completas. Trabalha fins de semana.',
           es:'Automatización, reemplazo de celdas de sal e instalaciones completas. Trabaja fines de semana.' },
      4: { en:'Tile, plaster and surface repair for residential and commercial pools. Quote on request.',
           pt:'Azulejo, reboco e reparo de superfícies para piscinas residenciais e comerciais. Orçamento sob consulta.',
           es:'Azulejo, yeso y reparación de superficies para piscinas residenciales y comerciales. Cotización a solicitud.' },
    };
    return (map[tech.id] || map[1])[lang] || (map[tech.id] || map[1]).en;
  };

  return (
    <div style={{display:'flex', flexDirection:'column', gap:12}}>
      {TECHS.map(tech => (
        <article key={tech.id} className="pg-card" style={{padding:'14px 16px 14px'}}>
          <div style={{display:'flex', alignItems:'center', gap:10, marginBottom:8}}>
            <Avatar name={tech.name} size={28}/>
            <h3 style={{margin:0, fontFamily:'var(--pg-font-display)', fontSize:16, fontWeight:700, letterSpacing:'-0.015em', flex:1, minWidth:0}}>{tech.name}</h3>
            <span style={{display:'inline-flex', alignItems:'center', gap:3, fontSize:12, color:'var(--pg-ink-700)', fontWeight:600}}>
              <Stars rating={tech.rating} size={11}/> {tech.rating}
            </span>
          </div>
          <p style={{margin:0, fontSize:13, lineHeight:1.45, color:'var(--pg-ink-700)'}}>
            {descForTech(tech, lang)}
          </p>
          <div style={{display:'flex', flexDirection:'column', gap:6, marginTop:10, fontSize:12.5, color:'var(--pg-ink-500)'}}>
            <div style={{display:'flex', alignItems:'center', gap:12, flexWrap:'wrap'}}>
              <span style={{display:'inline-flex', alignItems:'center', gap:5}}>
                {Icon.pin(13, 'var(--pg-ink-500)')} {tech.loc}
              </span>
              <span style={{display:'inline-flex', alignItems:'center', gap:5}}>
                {Tool(13, 'var(--pg-ink-500)')} {tr(tech.speciality, lang)}
              </span>
            </div>
            <div style={{display:'inline-flex', alignItems:'center', gap:5}}>
              {Icon.shield(13, 'var(--pg-ink-500)')} {verifiedLbl} · {tech.jobs} {lang==='pt'?'trabalhos':lang==='es'?'trabajos':'jobs'}
            </div>
          </div>
          <div className="pg-divider" style={{margin:'12px 0'}}/>
          <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
            <div style={{
              fontFamily:'var(--pg-font-display)', fontSize:16, fontWeight:700,
              color: tr(tech.rate, lang).toLowerCase().includes('quote') || tr(tech.rate, lang).toLowerCase().includes('orça') || tr(tech.rate, lang).toLowerCase().includes('cotiz') ? 'var(--pg-aqua-700)' : 'var(--pg-blue-500)',
              letterSpacing:'-0.01em',
            }}>{tr(tech.rate, lang)}</div>
            <div style={{display:'flex', gap:8}}>
              <button onClick={onChat} className="pg-btn pg-btn-ghost" style={{height:36, padding:'0 14px', fontSize:13, borderRadius:999}}>
                {Icon.msg(14, 'var(--pg-blue-700)')}
              </button>
              <button className="pg-btn pg-btn-primary" style={{height:36, padding:'0 18px', fontSize:13, borderRadius:999}}>{t.contact}</button>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}

// ── Vacation panel ────────────────────────────────────────────
function VacationPanel({ t, lang, vacTab, setVacTab, onChat, onCreate }) {
  const boost = {
    title: lang==='pt'
      ? 'Cobrir férias impulsiona seu perfil'
      : lang==='es'
        ? 'Cubrir vacaciones impulsa tu perfil'
        : 'Covering vacations boosts your profile',
    body: lang==='pt'
      ? 'Pool guys que cobrem férias ganham impulsionamento no perfil e melhores avaliações — aparecendo no topo das buscas.'
      : lang==='es'
        ? 'Los pool guys que cubren vacaciones obtienen impulso en el perfil y mejores reseñas — apareciendo en el top de las búsquedas.'
        : 'Pool guys who cover vacations earn a profile boost and better reviews — showing up at the top of searches.',
    chip: lang==='pt' ? '+ Visibilidade · + Avaliações' : lang==='es' ? '+ Visibilidad · + Reseñas' : '+ Visibility · + Reviews',
  };

  return (
    <div style={{display:'flex', flexDirection:'column', gap:14}}>
      {/* Profile-boost info card */}
      <div className="pg-card" style={{
        padding:'14px 14px', position:'relative', overflow:'hidden',
        background:'linear-gradient(135deg, var(--pg-blue-900) 0%, var(--pg-blue-700) 100%)',
        border:'none', color:'#fff',
      }}>
        <div style={{position:'absolute', right:-30, top:-30, width:120, height:120, borderRadius:'50%',
          background:'oklch(0.85 0.15 90 / 0.16)', pointerEvents:'none'}}/>
        <div style={{display:'flex', gap:12, alignItems:'flex-start', position:'relative'}}>
          <div style={{
            width:40, height:40, borderRadius:11, flexShrink:0,
            background:'oklch(0.85 0.15 90)',
            display:'flex', alignItems:'center', justifyContent:'center',
            boxShadow:'0 4px 10px oklch(0.55 0.16 80 / 0.4)',
          }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="var(--pg-blue-900)">
              <path d="M12 2l2.39 7.36H22l-6.18 4.49L18.18 22 12 17.27 5.82 22l2.36-8.15L2 9.36h7.61z"/>
            </svg>
          </div>
          <div style={{flex:1, minWidth:0}}>
            <div style={{fontFamily:'var(--pg-font-display)', fontSize:14.5, fontWeight:700, letterSpacing:'-0.01em', lineHeight:1.3}}>
              {boost.title}
            </div>
            <div style={{fontSize:12, opacity:0.85, marginTop:5, lineHeight:1.45}}>
              {boost.body}
            </div>
            <div style={{
              display:'inline-flex', alignItems:'center', gap:5, marginTop:9,
              padding:'4px 9px', borderRadius:7, background:'oklch(0.85 0.15 90 / 0.20)',
              fontSize:11, fontWeight:700, color:'oklch(0.92 0.12 90)', letterSpacing:'0.03em',
            }}>{boost.chip}</div>
          </div>
        </div>
      </div>

      <div className="pg-card" style={{
        padding:16, background:'linear-gradient(135deg, var(--pg-aqua-100), var(--pg-blue-100))',
        border:'none', position:'relative', overflow:'hidden',
      }}>
        <div style={{display:'flex', gap:14, alignItems:'flex-start'}}>
          <div style={{
            width:44, height:44, borderRadius:12, background:'#fff',
            display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0,
          }}>{Icon.cal(20, 'var(--pg-blue-500)')}</div>
          <div style={{flex:1, minWidth:0}}>
            <div style={{fontFamily:'var(--pg-font-display)', fontSize:15, fontWeight:700, letterSpacing:'-0.01em'}}>{t.goingOnVacation}</div>
            <div style={{fontSize:12, color:'var(--pg-ink-700)', marginTop:3, lineHeight:1.4}}>{t.vacationDesc}</div>
            <button onClick={onCreate} className="pg-btn pg-btn-aqua" style={{height:36, padding:'0 14px', fontSize:13, marginTop:10, borderRadius:999}}>
              {Icon.plus(15, 'var(--pg-blue-900)')} {t.postAvailability}
            </button>
          </div>
        </div>
      </div>

      <div className="pg-seg">
        <button className={`pg-seg-btn ${vacTab==='posted'?'on':''}`} onClick={()=>setVacTab('posted')}>
          {t.posted} ({VACATIONS_POSTED.length})
        </button>
        <button className={`pg-seg-btn ${vacTab==='applied'?'on':''}`} onClick={()=>setVacTab('applied')}>
          {t.appliedTab} ({VACATIONS_APPLIED.length})
        </button>
      </div>

      {vacTab === 'posted' && VACATIONS_POSTED.map(v => (
        <article key={v.id} className="pg-card" style={{padding:14}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:10}}>
            <div style={{minWidth:0}}>
              <div style={{display:'flex', alignItems:'center', gap:6, marginBottom:4}}>
                <span className="pg-badge pg-badge-new">{t.open}</span>
                <span style={{fontSize:11, color:'var(--pg-ink-500)'}}>
                  {v.applicants} {v.applicants>1 ? t.applicants : t.applicant}
                </span>
              </div>
              <h3 style={{margin:0, fontFamily:'var(--pg-font-display)', fontSize:15, fontWeight:700, letterSpacing:'-0.01em'}}>{tr(v.month, lang)}</h3>
              <div style={{display:'flex', alignItems:'center', gap:6, marginTop:4, fontSize:12, color:'var(--pg-ink-500)'}}>
                {Icon.pin(12)} {v.region}
              </div>
            </div>
            <div style={{textAlign:'right'}}>
              <div style={{fontSize:11, color:'var(--pg-ink-500)'}}>{v.poolsPerDay} {t.poolsPerDay}</div>
              {v.price==='neg' ? (
                <div style={{fontSize:14, fontWeight:700, marginTop:2, color:'var(--pg-aqua-700)'}}>{t.negotiable}</div>
              ) : (
                <div style={{fontFamily:'var(--pg-font-display)', fontSize:18, fontWeight:700, color:'var(--pg-blue-500)', letterSpacing:'-0.02em', marginTop:2}}>${v.price}</div>
              )}
            </div>
          </div>
          <div style={{marginTop:12}}>
            <div style={{fontSize:11, color:'var(--pg-ink-500)', fontWeight:600, letterSpacing:'0.04em', marginBottom:6}}>{t.selectedDays}</div>
            <MiniCal days={v.days}/>
          </div>
          <div style={{display:'flex', gap:8, marginTop:12, paddingTop:12, borderTop:'0.5px solid var(--pg-ink-200)'}}>
            <button className="pg-btn pg-btn-ghost" style={{flex:1, height:36, fontSize:13, borderRadius:999}}>{t.viewApplicants}</button>
            <button className="pg-btn pg-btn-outline" style={{flex:1, height:36, fontSize:13, borderRadius:999}}>{t.edit}</button>
          </div>
        </article>
      ))}

      {vacTab === 'applied' && VACATIONS_APPLIED.map(v => (
        <article key={v.id} className="pg-card" style={{padding:14}}>
          <div style={{display:'flex', alignItems:'center', gap:10, marginBottom:10}}>
            <Avatar name={v.owner} size={36}/>
            <div style={{flex:1, minWidth:0}}>
              <div style={{fontSize:14, fontWeight:600}}>{v.owner}</div>
              <div style={{fontSize:11, color:'var(--pg-ink-500)'}}>{v.region}</div>
            </div>
            {v.status === 'accepted' ? (
              <span className="pg-badge pg-badge-new" style={{background:'var(--pg-aqua-100)', color:'var(--pg-aqua-700)'}}>
                {Icon.check(11, 'var(--pg-aqua-700)')} {t.accepted}
              </span>
            ) : (
              <span className="pg-badge pg-badge-premium">{t.awaiting}</span>
            )}
          </div>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'flex-end', gap:10}}>
            <div>
              <div style={{fontSize:13, fontWeight:600}}>{tr(v.month, lang)}</div>
              <div style={{fontSize:12, color:'var(--pg-ink-500)', marginTop:2}}>{v.poolsPerDay} {t.poolsPerDay} · {v.days.length} {t.days}</div>
            </div>
            <div style={{fontFamily:'var(--pg-font-display)', fontSize:18, fontWeight:700, color:'var(--pg-blue-500)', letterSpacing:'-0.02em'}}>${v.price}/{lang==='en'?'pool':'piscina'}</div>
          </div>
          <MiniCal days={v.days} variant={v.status==='accepted'?'aqua':'blue'} style={{marginTop:10}}/>
          <div style={{display:'flex', gap:8, marginTop:12}}>
            <button onClick={onChat} className="pg-btn pg-btn-ghost" style={{flex:1, height:36, fontSize:13, borderRadius:999}}>
              {Icon.msg(14, 'var(--pg-blue-700)')} Chat
            </button>
            {v.status === 'accepted' ? (
              <button className="pg-btn pg-btn-aqua" style={{flex:1, height:36, fontSize:13, borderRadius:999}}>{t.viewSchedule}</button>
            ) : (
              <button className="pg-btn pg-btn-outline" style={{flex:1, height:36, fontSize:13, borderRadius:999}}>{t.withdraw}</button>
            )}
          </div>
        </article>
      ))}
    </div>
  );
}

// ── New Vacation creation sheet ───────────────────────────────
function PostVacationSheet({ onClose, lang='en', onSubmit }) {
  const t = STRINGS[lang];
  const months = lang==='pt'
    ? ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro']
    : lang==='es'
      ? ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre']
      : ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const dayShort = lang==='pt'
    ? ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb']
    : lang==='es'
      ? ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb']
      : ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  const dayFull = lang==='pt'
    ? ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado']
    : lang==='es'
      ? ['Domingo','Lunes','Martes','Miércoles','Jueves','Viernes','Sábado']
      : ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];

  const [monthIdx, setMonthIdx] = React.useState(6); // July
  const [year] = React.useState(2026);
  const [selectedDays, setSelectedDays] = React.useState(new Set());
  const [weekdayRegions, setWeekdayRegions] = React.useState({}); // {1:'Weston', 2:'Davie', ...}
  const [price, setPrice] = React.useState('55');
  const [priceMode, setPriceMode] = React.useState('fixed');

  // Calendar — get days in selected month
  const daysInMonth = new Date(year, monthIdx + 1, 0).getDate();
  const firstDow = new Date(year, monthIdx, 1).getDay(); // 0=Sun

  const toggleDay = (d) => {
    setSelectedDays(prev => {
      const next = new Set(prev);
      if (next.has(d)) next.delete(d); else next.add(d);
      return next;
    });
  };

  // Compute which weekdays are represented in selectedDays
  const involvedWeekdays = React.useMemo(() => {
    const set = new Set();
    selectedDays.forEach(d => set.add(new Date(year, monthIdx, d).getDay()));
    return [...set].sort();
  }, [selectedDays, monthIdx, year]);

  // Flatten city list
  const allCities = React.useMemo(() => {
    const out = [];
    Object.entries(FL_COUNTIES).forEach(([county, cities]) =>
      cities.forEach(city => out.push({ city, county })));
    return out;
  }, []);

  const headLbl = lang==='pt'?'Publicar disponibilidade':lang==='es'?'Publicar disponibilidad':'Post availability';
  const monthLbl= lang==='pt'?'Mês':lang==='es'?'Mes':'Month';
  const daysLbl = lang==='pt'?'Dias em que estarei fora':lang==='es'?'Días que estaré fuera':'Days I will be away';
  const regsLbl = lang==='pt'?'Região por dia da semana':lang==='es'?'Región por día de la semana':'Region by weekday';
  const priceLbl= lang==='pt'?'Preço por piscina':lang==='es'?'Precio por piscina':'Price per pool';
  const submitLbl=lang==='pt'?'Publicar férias':lang==='es'?'Publicar vacaciones':'Post vacation';
  const pickReg = lang==='pt'?'Escolher cidade':lang==='es'?'Elegir ciudad':'Pick city';

  return (
    <div style={{padding:'8px 0 24px'}}>
      <div style={{padding:'4px 18px 14px', display:'flex', alignItems:'center', justifyContent:'space-between'}}>
        <button onClick={onClose} style={{
          border:'none', background:'transparent', color:'var(--pg-blue-500)',
          fontSize:15, fontWeight:600, cursor:'pointer', padding:0,
        }}>{t.cancel}</button>
        <h2 style={{margin:0, fontFamily:'var(--pg-font-display)', fontSize:17, fontWeight:700, letterSpacing:'-0.01em'}}>{headLbl}</h2>
        <div style={{width:60}}/>
      </div>

      <div style={{padding:'0 18px', display:'flex', flexDirection:'column', gap:18}}>
        {/* Month picker */}
        <div>
          <div style={{fontSize:11, color:'var(--pg-ink-500)', fontWeight:700, letterSpacing:'0.06em', marginBottom:8}}>{monthLbl.toUpperCase()}</div>
          <div className="pg-scroll-x" style={{display:'flex', gap:6, marginLeft:-18, marginRight:-18, padding:'2px 18px'}}>
            {months.map((m, i) => (
              <button key={m} onClick={()=>{ setMonthIdx(i); setSelectedDays(new Set()); setWeekdayRegions({}); }}
                className={`pg-chip ${monthIdx===i?'pg-chip-on':''}`}>
                {m} {year}
              </button>
            ))}
          </div>
        </div>

        {/* Days picker */}
        <div>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:8}}>
            <div style={{fontSize:11, color:'var(--pg-ink-500)', fontWeight:700, letterSpacing:'0.06em'}}>{daysLbl.toUpperCase()}</div>
            <div style={{fontSize:11, color:'var(--pg-aqua-700)', fontWeight:600}}>
              {selectedDays.size} {t.days}
            </div>
          </div>
          <div className="pg-card" style={{padding:'12px 12px'}}>
            <div style={{display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:4, marginBottom:6}}>
              {dayShort.map(d => (
                <div key={d} style={{fontSize:10, color:'var(--pg-ink-500)', textAlign:'center', fontWeight:600}}>{d}</div>
              ))}
            </div>
            <div style={{display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:4}}>
              {Array.from({length: firstDow}).map((_, i) => (
                <div key={`spacer-${i}`}/>
              ))}
              {Array.from({length: daysInMonth}, (_, i) => i+1).map(d => {
                const on = selectedDays.has(d);
                return (
                  <button key={d} onClick={()=>toggleDay(d)} style={{
                    aspectRatio:'1', borderRadius:8, fontSize:12, fontWeight:600,
                    display:'flex', alignItems:'center', justifyContent:'center',
                    background: on ? 'var(--pg-blue-500)' : 'transparent',
                    color: on ? '#fff' : 'var(--pg-ink-700)',
                    border:'none', cursor:'pointer', fontFamily:'inherit',
                    transition:'all .12s ease',
                  }}>{d}</button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Region per weekday */}
        {involvedWeekdays.length > 0 && (
          <div>
            <div style={{fontSize:11, color:'var(--pg-ink-500)', fontWeight:700, letterSpacing:'0.06em', marginBottom:8}}>{regsLbl.toUpperCase()}</div>
            <div style={{display:'flex', flexDirection:'column', gap:8}}>
              {involvedWeekdays.map(wd => (
                <WeekdayRegionRow key={wd}
                  label={dayFull[wd]}
                  value={weekdayRegions[wd] || ''}
                  cities={allCities}
                  onChange={(city)=>setWeekdayRegions(r=>({...r, [wd]:city}))}
                  placeholder={pickReg}
                  lang={lang}
                />
              ))}
            </div>
          </div>
        )}

        {/* Price */}
        <div>
          <div style={{fontSize:11, color:'var(--pg-ink-500)', fontWeight:700, letterSpacing:'0.06em', marginBottom:8}}>{priceLbl.toUpperCase()}</div>
          <div className="pg-seg" style={{marginBottom:10}}>
            <button className={`pg-seg-btn ${priceMode==='fixed'?'on':''}`} onClick={()=>setPriceMode('fixed')}>{t.fixedPrice}</button>
            <button className={`pg-seg-btn ${priceMode==='neg'?'on':''}`} onClick={()=>setPriceMode('neg')}>{t.priceNeg}</button>
          </div>
          {priceMode === 'fixed' && (
            <div style={{position:'relative'}}>
              <span style={{position:'absolute', left:16, top:'50%', transform:'translateY(-50%)', fontSize:22, fontWeight:700, color:'var(--pg-blue-500)', fontFamily:'var(--pg-font-display)'}}>$</span>
              <input className="pg-field" value={price} onChange={e=>setPrice(e.target.value)}
                style={{height:60, paddingLeft:36, fontSize:26, fontWeight:700, color:'var(--pg-blue-500)', letterSpacing:'-0.02em', fontFamily:'var(--pg-font-display)'}}/>
              <span style={{position:'absolute', right:16, top:'50%', transform:'translateY(-50%)', fontSize:13, color:'var(--pg-ink-500)'}}>{t.perPool}</span>
            </div>
          )}
        </div>
      </div>

      <div style={{padding:'18px 18px 8px', position:'sticky', bottom:0, background:'#fff'}}>
        <button onClick={onSubmit}
          disabled={selectedDays.size === 0 || involvedWeekdays.some(wd => !weekdayRegions[wd])}
          className="pg-btn pg-btn-primary"
          style={{
            width:'100%', height:52, fontSize:16,
            opacity: (selectedDays.size === 0 || involvedWeekdays.some(wd => !weekdayRegions[wd])) ? 0.45 : 1,
          }}>
          {Icon.cal(17, '#fff')} {submitLbl}
        </button>
      </div>
    </div>
  );
}

function WeekdayRegionRow({ label, value, cities, onChange, placeholder, lang }) {
  const [open, setOpen] = React.useState(false);
  const [q, setQ] = React.useState('');
  const matches = q.trim().length >= 1
    ? cities.filter(c => c.city.toLowerCase().includes(q.trim().toLowerCase())).slice(0, 5)
    : cities.slice(0, 5);

  return (
    <div className="pg-card" style={{padding:'10px 14px'}}>
      <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', gap:10}}>
        <div style={{display:'flex', alignItems:'center', gap:10, minWidth:0, flex:1}}>
          <div style={{
            width:36, height:36, borderRadius:10, background:'var(--pg-blue-100)',
            display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0,
            fontSize:12, fontWeight:700, color:'var(--pg-blue-700)',
            fontFamily:'var(--pg-font-display)', letterSpacing:'-0.01em',
          }}>{label.slice(0,3)}</div>
          <div style={{minWidth:0, flex:1}}>
            <div style={{fontSize:13, fontWeight:600, color:'var(--pg-ink-900)'}}>{label}</div>
            {value
              ? <div style={{fontSize:11.5, color:'var(--pg-aqua-700)', display:'flex', alignItems:'center', gap:4, marginTop:1}}>
                  {Icon.pin(11, 'var(--pg-aqua-700)')} {value}
                </div>
              : <div style={{fontSize:11.5, color:'var(--pg-ink-500)', marginTop:1}}>{placeholder}</div>}
          </div>
        </div>
        <button onClick={()=>{ setOpen(!open); setQ(''); }} style={{
          border:'1px solid var(--pg-ink-200)', background:'#fff', height:30, padding:'0 12px',
          borderRadius:8, fontSize:12, fontWeight:600, color:'var(--pg-blue-500)', cursor:'pointer',
          fontFamily:'inherit', display:'inline-flex', alignItems:'center', gap:4,
        }}>{value ? (lang==='pt'?'Mudar':lang==='es'?'Cambiar':'Change') : (lang==='pt'?'Selecionar':lang==='es'?'Seleccionar':'Select')}</button>
      </div>

      {open && (
        <div style={{marginTop:10, paddingTop:10, borderTop:'0.5px solid var(--pg-ink-200)'}}>
          <div style={{position:'relative', marginBottom:8}}>
            <input className="pg-field" value={q} onChange={e=>setQ(e.target.value)}
              placeholder={lang==='pt'?'Buscar cidade…':lang==='es'?'Buscar ciudad…':'Search city…'}
              style={{paddingLeft:38, height:38}}/>
            <span style={{position:'absolute', left:14, top:'50%', transform:'translateY(-50%)'}}>
              {Icon.search(15, 'var(--pg-ink-500)')}
            </span>
          </div>
          <div style={{display:'flex', flexDirection:'column', gap:4, maxHeight:180, overflow:'auto'}}>
            {matches.map(m => (
              <button key={m.city} onClick={()=>{ onChange(m.city); setOpen(false); }} style={{
                display:'flex', alignItems:'center', gap:8, padding:'8px 10px',
                background: m.city === value ? 'var(--pg-aqua-100)' : 'transparent',
                border:'none', borderRadius:8, cursor:'pointer', textAlign:'left',
                fontFamily:'inherit', fontSize:13,
              }}>
                {Icon.pin(13, 'var(--pg-blue-500)')}
                <span style={{flex:1, fontWeight:500}}>{m.city}</span>
                <span style={{fontSize:11, color:'var(--pg-ink-500)'}}>{m.county}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function MiniCal({ days, variant='blue', style={} }) {
  const set = new Set(days);
  const all = Array.from({length:31}, (_,i)=>i+1);
  const c = variant==='aqua' ? 'var(--pg-aqua-500)' : 'var(--pg-blue-500)';
  const cBg = variant==='aqua' ? 'var(--pg-aqua-100)' : 'var(--pg-blue-100)';
  return (
    <div style={{display:'grid', gridTemplateColumns:'repeat(7, 1fr)', gap:4, ...style}}>
      {all.map(d => {
        const on = set.has(d);
        return (
          <div key={d} style={{
            aspectRatio:'1', borderRadius:6, fontSize:10, fontWeight:600,
            display:'flex', alignItems:'center', justifyContent:'center',
            background: on ? c : cBg, color: on ? '#fff' : 'var(--pg-ink-500)',
          }}>{d}</div>
        );
      })}
    </div>
  );
}

Object.assign(window, { WorkScreen });
