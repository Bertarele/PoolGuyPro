// app.jsx — root, tab routing, overlays

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "tier": "free",
  "lang": "en",
  "density": "regular",
  "showDevControls": true
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [tab, setTab] = React.useState('home');
  const screenRef = React.useRef(null);

  const switchTab = React.useCallback((newTab) => {
    setTab(newTab);
    // Scroll to top whenever a new tab is selected
    requestAnimationFrame(() => {
      if (screenRef.current) screenRef.current.scrollTop = 0;
    });
  }, []);
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  const [user, setUser] = React.useState({
    name:'Lucas Mendes', tier: t.tier, rating: 4.9, reviews: 128,
    regions:['Broward','Weston','Plantation'],
    // Profile fields — pre-filled on job applications
    age: 31,
    region: 'Fort Lauderdale, FL',
    hasCar: true,
    hasLicense: true,
    hasEquipment: true,
    equipment: {
      en: ['Pentair VS pump', 'Pool vacuum robot', 'Chemical test kit'],
      pt: ['Bomba Pentair VS', 'Robô aspirador', 'Kit de teste químico'],
      es: ['Bomba Pentair VS', 'Robot aspiradora', 'Kit de prueba química'],
    },
    experience: [
      { company: 'Self-employed',
        role: {en:'Independent Pool Technician', pt:'Técnico de Piscinas Autônomo', es:'Técnico de Piscinas Independiente'},
        duration: {en:'4+ yrs', pt:'4+ anos', es:'4+ años'},
        desc: {en:'Managed my own service route with 30+ regular clients across Broward County. Chemical balancing, equipment repair, client relations.',
               pt:'Gerenciei minha própria rota com 30+ clientes fixos no Broward County. Balanceamento químico, reparos e atendimento ao cliente.',
               es:'Gestioné mi propia ruta con 30+ clientes fijos en el Condado de Broward. Balance químico, reparaciones y atención al cliente.'} },
    ],
  });
  const [lang, setLangState] = React.useState(t.lang);
  // Per-weekday region preferences for notifications
  const [regionsByDay, setRegionsByDay] = React.useState({
    mon: ['Pompano Beach','Fort Lauderdale'],
    tue: ['Deerfield Beach','Boca Raton'],
    wed: ['Pompano Beach','Fort Lauderdale'],
    thu: ['Plantation','Davie'],
    fri: ['Weston','Plantation'],
    sat: [],
    sun: [],
  });
  const [county] = React.useState('Broward');

  // Overlays
  const [chatOpen,       setChatOpen]      = React.useState(false);
  const [chatConvoName,  setChatConvoName]  = React.useState(null);
  const [notifOpen,      setNotifOpen]      = React.useState(false);
  const [payOpen,        setPayOpen]        = React.useState(false);
  const [postMenuOpen,   setPostMenuOpen]   = React.useState(false);
  const [postQPOpen,     setPostQPOpen]     = React.useState(false);
  const [regionOpen,     setRegionOpen]     = React.useState(false);
  const [langPickerOpen, setLangPickerOpen] = React.useState(false);
  const [applicantsPost, setApplicantsPost] = React.useState(null);
  const [verifyOpen,     setVerifyOpen]     = React.useState(false);
  const [pushNotifOpen,  setPushNotifOpen]  = React.useState(false);
  const [toast,          setToast]          = React.useState(null);
  const [walletOpen,     setWalletOpen]     = React.useState(false);
  const [jobDetailApp,   setJobDetailApp]   = React.useState(null);
  const [reviewApp,      setReviewApp]      = React.useState(null);
  const [vacSheetOpen,   setVacSheetOpen]   = React.useState(false);
  const [hiringSheetOpen,setHiringSheetOpen]= React.useState(false);
  const [techSheetOpen,  setTechSheetOpen]  = React.useState(false);
  const [dayPickerVac,   setDayPickerVac]   = React.useState(null);
  const [scheduleApp,    setScheduleApp]    = React.useState(null);
  const [hiringAppDetail,setHiringAppDetail]= React.useState(null);
  const [applyJob,       setApplyJob]       = React.useState(null);
  const [editProfileOpen,setEditProfileOpen]= React.useState(false);

  // Sync tier tweak → user state
  React.useEffect(()=>{ setUser(u=>({...u, tier:t.tier})); }, [t.tier]);

  const setLang = (l) => {
    setLangState(l);
    setTweak('lang', l);
  };

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(()=>setToast(null), 2400);
  };

  const ctx = {
    user,
    setUser: (u) => {
      const next = typeof u === 'function' ? u(user) : u;
      setUser(next);
      if (next.tier !== t.tier) setTweak('tier', next.tier);
    },
    lang, setLang,
    regionsByDay, setRegionsByDay, county,
    goTab:              switchTab,
    openChat:           (name=null) => { setChatConvoName(name); setChatOpen(true); },
    openNotifications:  () => setNotifOpen(true),
    openPaywall:        () => setPayOpen(true),
    openPostMenu:       () => setPostMenuOpen(true),
    openPost:           () => setPostQPOpen(true),
    openRegionEditor:   () => setRegionOpen(true),
    openLanguagePicker: () => setLangPickerOpen(true),
    openApplicants:     (post) => setApplicantsPost(post),
    openVerification:   () => setVerifyOpen(true),
    openPushNotif:      () => setPushNotifOpen(true),
    openWallet:         () => setWalletOpen(true),
    openJobDetail:      (app) => setJobDetailApp(app),
    openReview:         (app) => setReviewApp(app),
    openVacSheet:       () => setVacSheetOpen(true),
    openHiringSheet:    () => setHiringSheetOpen(true),
    openTechSheet:      () => setTechSheetOpen(true),
    openDayPicker:      (vac) => setDayPickerVac(vac),
    openSchedule:       (app) => setScheduleApp(app),
    openHiringAppDetail:(app) => setHiringAppDetail(app),
    openApplyJob:       (job) => setApplyJob(job),
    openEditProfile:    ()    => setEditProfileOpen(true),
  };

  // Build confirmed-day map from accepted vacation applications (for conflict detection)
  const confirmedDays = React.useMemo(() => {
    return VACATIONS_APPLIED
      .filter(v => v.status === 'accepted' && v.yearMonth)
      .flatMap(v => (v.selectedDays || v.days).map(d => ({
        key: `${v.yearMonth.year}-${v.yearMonth.month}-${d}`,
        owner: v.owner,
      })));
  }, []);

  // Find the conversation object matching chatConvoName, or create a stub for new chats
  const initialConvo = React.useMemo(() => {
    if (!chatConvoName) return null;
    const first = chatConvoName.split(' ')[0];
    const found = CHAT_CONVERSATIONS.find(c => c.name.startsWith(first));
    if (found) return found;
    // Stub: open a new conversation directly without showing the inbox
    return {
      id: 'stub-' + chatConvoName,
      name: chatConvoName,
      unread: 0,
      time:    { en:'just now', pt:'agora', es:'ahora' },
      lastMsg: { en:'Start a conversation…', pt:'Inicie uma conversa…', es:'Inicia una conversación…' },
      context: { en:'Direct message', pt:'Mensagem direta', es:'Mensaje directo' },
    };
  }, [chatConvoName, chatOpen]);

  return (
    <div style={{
      width:402, height:874, position:'relative', overflow:'hidden',
      borderRadius:48, background:'var(--pg-bg)',
    }}>

      {/* ── Login screen ── */}
      {!isLoggedIn && (
        <div style={{position:'absolute', inset:0, zIndex:100}}>
          <div style={{position:'absolute', top:0, left:0, right:0, zIndex:25, background:'transparent'}}>
            <IOSStatusBar dark={true}/>
          </div>
          <div style={{position:'absolute', inset:0, paddingTop:54, overflow:'auto'}}>
            <LoginScreen onLogin={()=>setIsLoggedIn(true)} lang={lang} setLang={setLang}/>
          </div>
        </div>
      )}

      {/* ── Main app ── */}
      {isLoggedIn && (
        <>
          {/* Screen content */}
          <div ref={screenRef} style={{position:'absolute', inset:0, paddingTop:54, overflow:'auto'}}>
            {tab === 'home'    && <HomeScreen ctx={ctx}/>}
            {tab === 'market'  && <MarketplaceScreen ctx={ctx}/>}
            {tab === 'quick'   && <QuickPoolsScreen ctx={ctx}/>}
            {tab === 'work'    && <WorkScreen ctx={ctx}/>}
            {tab === 'profile' && <ProfileScreen ctx={ctx}/>}
          </div>

          {/* Status bar */}
          <div style={{position:'absolute', top:0, left:0, right:0, zIndex:25, background:'transparent'}}>
            <IOSStatusBar dark={true}/>
          </div>

          {/* Tab bar */}
          <TabBar tab={tab} setTab={switchTab} lang={lang}/>

          {/* Overlays */}
          <ChatSheet open={chatOpen}
            onClose={()=>{ setChatOpen(false); setChatConvoName(null); }}
            lang={lang} initialConvo={initialConvo}/>
          <NotificationsSheet open={notifOpen} onClose={()=>setNotifOpen(false)} lang={lang}/>
          <PaywallSheet open={payOpen} onClose={()=>setPayOpen(false)} setUser={ctx.setUser} lang={lang}/>
          <PostMenuSheet open={postMenuOpen} onClose={()=>setPostMenuOpen(false)}
            onPickQuickPool={()=>setPostQPOpen(true)} lang={lang}/>
          <Sheet open={postQPOpen} onClose={()=>setPostQPOpen(false)} height="92%">
            <PostQuickPool
              lang={lang}
              onClose={()=>setPostQPOpen(false)}
              onSubmit={()=>{
                setPostQPOpen(false);
                showToast(STRINGS[lang].toastPosted);
                setTab('quick');
              }}
            />
          </Sheet>
          <Toast message={toast}/>

          {/* Region editor */}
          <RegionEditorSheet
            open={regionOpen} onClose={()=>setRegionOpen(false)} lang={lang}
            regionsByDay={regionsByDay} setRegionsByDay={setRegionsByDay}
            county={county}
          />

          {/* Language picker */}
          <LanguagePickerSheet
            open={langPickerOpen} onClose={()=>setLangPickerOpen(false)}
            lang={lang} setLang={setLang}
          />

          {/* Applicants sheet */}
          <ApplicantsSheet
            open={!!applicantsPost}
            onClose={()=>setApplicantsPost(null)}
            post={applicantsPost}
            lang={lang}
            onChat={(name)=>{ setApplicantsPost(null); setChatConvoName(name); setChatOpen(true); }}
          />

          {/* Verification sheet */}
          <VerificationSheet
            open={verifyOpen} onClose={()=>setVerifyOpen(false)} lang={lang}/>

          {/* Wallet sheet */}
          <WalletSheet
            open={walletOpen} onClose={()=>setWalletOpen(false)} lang={lang}/>

          {/* Work lifecycle sheet */}
          <WorkLifecycleSheet
            open={!!jobDetailApp} onClose={()=>setJobDetailApp(null)}
            app={jobDetailApp} lang={lang}
            onReview={(app)=>{ setJobDetailApp(null); setReviewApp(app); }}/>

          {/* Review sheet */}
          <ReviewSheet
            open={!!reviewApp} onClose={()=>setReviewApp(null)}
            app={reviewApp} lang={lang}
            onSubmitDone={()=>{ setReviewApp(null); showToast(lang==='pt'?'Avaliação enviada ✓':lang==='es'?'Reseña enviada ✓':'Review submitted ✓'); }}/>

          {/* Work — vacation / hiring / tech sheets (app-level so backdrop covers full frame) */}
          <Sheet open={vacSheetOpen} onClose={()=>setVacSheetOpen(false)} height="92%">
            <PostVacationSheet
              lang={lang}
              onClose={()=>setVacSheetOpen(false)}
              onSubmit={()=>{ setVacSheetOpen(false); showToast(lang==='pt'?'Férias publicadas ✓':lang==='es'?'Vacaciones publicadas ✓':'Vacation posted ✓'); }}
            />
          </Sheet>
          <Sheet open={!!dayPickerVac} onClose={()=>setDayPickerVac(null)} height="88%">
            <VacationDayPickerSheet
              vac={dayPickerVac} lang={lang}
              confirmedDays={confirmedDays}
              onClose={()=>setDayPickerVac(null)}
              onSubmit={()=>setDayPickerVac(null)}
            />
          </Sheet>
          <Sheet open={hiringSheetOpen} onClose={()=>setHiringSheetOpen(false)} height="80%">
            <PostHiringSheet
              lang={lang}
              onClose={()=>setHiringSheetOpen(false)}
              onSubmit={()=>{ setHiringSheetOpen(false); showToast(lang==='pt'?'Vaga publicada ✓':lang==='es'?'Empleo publicado ✓':'Job posted ✓'); }}
            />
          </Sheet>
          <Sheet open={techSheetOpen} onClose={()=>setTechSheetOpen(false)} height="80%">
            <PostTechSheet
              lang={lang}
              onClose={()=>setTechSheetOpen(false)}
              onSubmit={()=>{ setTechSheetOpen(false); showToast(lang==='pt'?'Perfil publicado ✓':lang==='es'?'Perfil publicado ✓':'Profile posted ✓'); }}
            />
          </Sheet>

          {/* Apply to job sheet */}
          <ApplyJobSheet
            open={!!applyJob} onClose={()=>setApplyJob(null)}
            job={applyJob} user={user} lang={lang}
            onEditProfile={()=>setEditProfileOpen(true)}
            onSubmit={()=>{ setApplyJob(null); showToast(lang==='pt'?'Candidatura enviada ✓':lang==='es'?'Postulación enviada ✓':'Application sent ✓'); }}/>

          {/* Edit profile sheet */}
          <EditProfileSheet
            open={editProfileOpen} onClose={()=>setEditProfileOpen(false)}
            user={user} setUser={ctx.setUser} lang={lang}/>

          {/* Hiring application detail sheet */}
          <HiringAppDetailSheet
            open={!!hiringAppDetail} onClose={()=>setHiringAppDetail(null)}
            app={hiringAppDetail} lang={lang}/>

          {/* Coverage schedule sheet */}
          <Sheet open={!!scheduleApp} onClose={()=>setScheduleApp(null)} height="95%">
            <ScheduleSheet
              app={scheduleApp} lang={lang}
              onClose={()=>setScheduleApp(null)}
            />
          </Sheet>

          {/* Push notifications sheet */}
          <PushNotifSheet
            open={pushNotifOpen} onClose={()=>setPushNotifOpen(false)} lang={lang}
            onEnabled={()=>{ setPushNotifOpen(false); showToast(lang==='pt'?'Notificações ativadas ✓':lang==='es'?'Notificaciones activadas ✓':'Notifications enabled ✓'); }}/>

          {/* Home indicator */}
          <div style={{
            position:'absolute', bottom:0, left:0, right:0, zIndex:60,
            height:34, display:'flex', justifyContent:'center', alignItems:'flex-end',
            paddingBottom:8, pointerEvents:'none',
          }}>
            <div style={{width:139, height:5, borderRadius:100, background:'rgba(0,0,0,0.25)'}}/>
          </div>
        </>
      )}

      {/* Tweaks */}
      <TweaksPanel>
        <TweakSection label="Subscription tier"/>
        <TweakRadio value={t.tier} options={['free','premium','pro']}
          onChange={v=>{ setTweak('tier', v); }}/>
        <div style={{fontSize:10, color:'rgba(41,38,27,.55)', lineHeight:1.4, marginTop:-4}}>
          Free = Quick Pools locked. Premium/PRO unlock apply + contact.
        </div>

        <TweakSection label="Language"/>
        <TweakRadio value={lang} options={['en','pt','es']}
          onChange={v=>setLang(v)}/>

        <TweakSection label="Quick jumps"/>
        <TweakButton onClick={()=>setIsLoggedIn(false)}>Show login screen</TweakButton>
        <TweakButton onClick={()=>{ setTab('quick'); }}>Open Quick Pools</TweakButton>
        <TweakButton onClick={()=>setPostMenuOpen(true)}>Open post menu</TweakButton>
        <TweakButton onClick={()=>setPostQPOpen(true)}>Open Post Quick Pool form</TweakButton>
        <TweakButton onClick={()=>setChatOpen(true)}>Open chat</TweakButton>
        <TweakButton onClick={()=>setPayOpen(true)}>Open paywall</TweakButton>
        <TweakButton onClick={()=>setNotifOpen(true)}>Open notifications</TweakButton>
        <TweakButton onClick={()=>setLangPickerOpen(true)}>Open language picker</TweakButton>
        <TweakButton onClick={()=>setApplicantsPost(MY_POSTS[0])}>Open applicants</TweakButton>
        <TweakButton onClick={()=>setWalletOpen(true)}>Open wallet</TweakButton>
        <TweakButton onClick={()=>setJobDetailApp(MY_APPLICATIONS[0])}>Job lifecycle (hired)</TweakButton>
        <TweakButton onClick={()=>setJobDetailApp(MY_APPLICATIONS[1])}>Job lifecycle (in progress)</TweakButton>
        <TweakButton onClick={()=>setReviewApp(MY_APPLICATIONS[3])}>Open review sheet</TweakButton>
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
