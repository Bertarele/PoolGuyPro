// login.jsx — splash + email/password login screen

function LoginScreen({ onLogin, lang='en', setLang }) {
  const t = STRINGS[lang];
  const [email, setEmail]     = React.useState('');
  const [pass,  setPass]      = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [showPass, setShowPass] = React.useState(false);

  const canSubmit = email.trim().length > 3 && pass.trim().length >= 4;

  const handleLogin = () => {
    if (!canSubmit || loading) return;
    setLoading(true);
    setTimeout(() => { setLoading(false); onLogin(); }, 900);
  };

  const langs = [
    { id:'en', flag:'🇺🇸', short:'EN' },
    { id:'pt', flag:'🇧🇷', short:'PT' },
    { id:'es', flag:'🇪🇸', short:'ES' },
  ];

  return (
    <div style={{ width:'100%', height:'100%', display:'flex', flexDirection:'column', background:'var(--pg-bg)' }}>

      {/* Top hero */}
      <div style={{
        background:'linear-gradient(170deg, var(--pg-navy-900) 0%, var(--pg-blue-600) 100%)',
        padding:'36px 28px 36px', flexShrink:0,
        display:'flex', flexDirection:'column', alignItems:'center', gap:14, position:'relative',
      }}>
        {/* Language switcher — top right */}
        <div style={{position:'absolute', top:14, right:16, display:'flex', gap:6}}>
          {langs.map(l => (
            <button key={l.id} onClick={()=>setLang(l.id)} style={{
              padding:'4px 8px', borderRadius:8, border:'none', cursor:'pointer',
              fontFamily:'inherit', fontSize:11, fontWeight:700, letterSpacing:'0.04em',
              background: lang===l.id ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.07)',
              color: lang===l.id ? '#fff' : 'rgba(255,255,255,0.55)',
              transition:'all .15s',
            }}>{l.flag} {l.short}</button>
          ))}
        </div>

        <Wordmark size="lg" onDark/>
        <p style={{
          margin:0, fontSize:13, color:'rgba(255,255,255,0.72)',
          textAlign:'center', lineHeight:1.5, maxWidth:260,
        }}>{t.loginSub}</p>
      </div>

      {/* Form */}
      <div style={{
        flex:1, padding:'28px 24px 24px', overflow:'auto',
        display:'flex', flexDirection:'column', gap:14,
      }}>
        {/* Email */}
        <div>
          <div style={{fontSize:10, fontWeight:700, letterSpacing:'0.08em', color:'var(--pg-ink-500)', marginBottom:7}}>
            EMAIL
          </div>
          <input
            className="pg-field"
            type="email"
            value={email}
            onChange={e=>setEmail(e.target.value)}
            onKeyDown={e=>e.key==='Enter'&&handleLogin()}
            placeholder="you@email.com"
            style={{height:50, fontSize:15}}
          />
        </div>

        {/* Password */}
        <div>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:7}}>
            <div style={{fontSize:10, fontWeight:700, letterSpacing:'0.08em', color:'var(--pg-ink-500)'}}>
              {t.passLbl.toUpperCase()}
            </div>
            <button style={{
              border:'none', background:'transparent', color:'var(--pg-blue-500)',
              fontSize:12, fontWeight:600, cursor:'pointer', padding:0,
            }}>{t.forgotPw}</button>
          </div>
          <div style={{position:'relative'}}>
            <input
              className="pg-field"
              type={showPass ? 'text' : 'password'}
              value={pass}
              onChange={e=>setPass(e.target.value)}
              onKeyDown={e=>e.key==='Enter'&&handleLogin()}
              placeholder="••••••••"
              style={{height:50, fontSize:15, paddingRight:46}}
            />
            <button onClick={()=>setShowPass(p=>!p)} style={{
              position:'absolute', right:14, top:'50%', transform:'translateY(-50%)',
              border:'none', background:'transparent', cursor:'pointer', padding:4,
              color:'var(--pg-ink-500)', display:'flex', alignItems:'center',
            }}>
              {showPass
                ? <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                : <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              }
            </button>
          </div>
        </div>

        {/* Login button */}
        <button
          onClick={handleLogin}
          disabled={!canSubmit || loading}
          className="pg-btn pg-btn-primary"
          style={{ width:'100%', height:52, fontSize:16, marginTop:4, opacity: canSubmit ? 1 : 0.45 }}
        >
          {loading ? (
            <span style={{display:'inline-flex', alignItems:'center', gap:9}}>
              <span style={{
                width:16, height:16, borderRadius:'50%',
                border:'2.5px solid rgba(255,255,255,0.3)', borderTopColor:'#fff',
                animation:'pgSpin .7s linear infinite', display:'inline-block',
              }}/>
              {t.loginBtn}
            </span>
          ) : t.loginBtn}
        </button>

        {/* Divider */}
        <div style={{display:'flex', alignItems:'center', gap:10}}>
          <div style={{flex:1, height:1, background:'var(--pg-ink-200)'}}/>
          <span style={{fontSize:12, color:'var(--pg-ink-400)'}}>{t.orLbl}</span>
          <div style={{flex:1, height:1, background:'var(--pg-ink-200)'}}/>
        </div>

        {/* Apple sign in */}
        <button style={{
          width:'100%', height:50, borderRadius:12,
          border:'1px solid var(--pg-ink-200)', background:'var(--pg-white)',
          cursor:'pointer', fontFamily:'inherit', fontWeight:600, fontSize:14,
          color:'var(--pg-ink-900)', display:'flex', alignItems:'center', justifyContent:'center', gap:9,
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
            <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
          </svg>
          {t.withApple}
        </button>

        {/* Continue as guest */}
        <button onClick={()=>onLogin()} style={{
          border:'none', background:'transparent', color:'var(--pg-ink-500)',
          fontSize:13, cursor:'pointer', padding:'2px 0', textDecoration:'underline',
          textDecorationColor:'var(--pg-ink-300)',
        }}>{t.continueGuest}</button>

        {/* Sign up */}
        <div style={{textAlign:'center', marginTop:'auto', paddingTop:4}}>
          <span style={{fontSize:13, color:'var(--pg-ink-500)'}}>{t.noAccount} </span>
          <button style={{
            border:'none', background:'transparent', color:'var(--pg-blue-500)',
            fontSize:13, fontWeight:700, cursor:'pointer', padding:0,
          }}>{t.signUp}</button>
        </div>
      </div>

      <style>{`@keyframes pgSpin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

Object.assign(window, { LoginScreen });
